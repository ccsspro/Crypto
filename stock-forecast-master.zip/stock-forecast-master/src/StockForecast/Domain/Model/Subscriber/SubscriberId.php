<?php

namespace Obokaman\StockForecast\Domain\Model\Subscriber;

use Obokaman\StockForecast\Domain\Model\Kernel\AggregateId;

class SubscriberId extends AggregateId
{

}