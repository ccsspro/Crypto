<?php

namespace Obokaman\StockForecast\Domain\Model\Subscriber;


class SubscriberExistsException extends \DomainException
{

}