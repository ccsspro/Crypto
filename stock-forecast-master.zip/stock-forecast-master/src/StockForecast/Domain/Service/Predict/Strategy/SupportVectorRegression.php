<?php

namespace Obokaman\StockForecast\Domain\Service\Predict\Strategy;

use Obokaman\StockForecast\Domain\Service\Predict\PredictionStrategy;

interface SupportVectorRegression extends PredictionStrategy
{
}
