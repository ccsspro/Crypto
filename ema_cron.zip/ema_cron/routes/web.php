<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('updateEMA', 'EventController@index');
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');
Route::get('listing', 'EventController@showlist')->name('list');
Route::post('dashboard-save', 'EventController@dashboard_save');
Route::post('dashboard-update', 'EventController@dashboard_update');
Route::post('alertDetails', 'EventController@alertDetails');
Route::get('calculateEMA', 'EventController@ema_check');
Route::post('duplicateDetails', 'EventController@duplicateDetails');
Route::post('cancelAlert', 'EventController@cancelAlert');
Route::get('testAlert', 'EventController@testAlert');
Route::get('edit/{id}','EventController@updateDetails')->name('updateDetails');
Route::get('primaryalert', 'EventController@primaryCheck');
Route::get('secondaryalert', 'EventController@secondaryCheck');
Route::get('statusupdate', 'EventController@statusUpdate');
Route::get('details/{id?}','EventController@Details')->name('details');
Route::get('sendmessage','EventController@sendMessage');
Route::get('getcurrency', 'HomeController@getcurrency')->name('currency');
Route::get('removeedit/{id?}','EventController@removeedit')->name('removeedit');
Route::get('showlist','EventController@showlist')->name('showlist');
Route::post('edit-data', 'EventController@editdata')->name('edit-data');
Route::post('entry-data', 'EventController@entrydata')->name('entry-data');
Route::get('detailsnew/{id?}','EventController@detailsnew')->name('detailsnew');
