@extends('layouts.app')
@section('content')
<!-- Home HTML Starts Here  -->

<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="content-wrap">
					<form action="{{asset('/')}}dashboard-update" method="post">
						{{ csrf_field() }}
						@foreach($client_obj as $key=>$value)
						<input type="hidden" name="getId" value="{{$value->client_id}}">
						<div class="row">
							<div class="col-12">
								<p>
									<select class="form-control d-inline-block" name="timeZone" required="true">
										<option value="Europe-London" @if($value->timeZone=="Europe-London") selected='selected' @endif>London, UK</option>
										<option value="Europe-Berlin" @if($value->timeZone=="Europe-Berlin") selected='selected' @endif>Berlin, Germany (GMT+1)</option>
										<option value="America-New_York" @if($value->timeZone=="America-New_York") selected='selected' @endif>New York, NY, USA (GMT-5)</option>
									</select>
								</p>
							</div>
							<div class="col-12">
								<p>Group of events</p>
								<p>
									that need to happen within &nbsp;&nbsp; 
									<input type="text" class="form-control d-inline-block w-three-digi" placeholder="Enter Time" name="scanInterval" onkeypress="return isNumberKey(event)" required="true" value="{{$value->scanInterval}}"> &nbsp;&nbsp; Minutes
								</p>
							</div>
						</div>
						
						<div class="row condition-add-row">
							<div class="col-12 content-row">
								<div class="content-wrap-one first">
									<p>
										Condition 1

									</p>
								</div>
								<div class="content-wrap-one second">
									<p>
										CLOSE PRICE &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="crossing" required="true">
											<option value="under"@if($value->crossing=="under") selected='selected' @endif>crosses under</option>
											<option value="over"@if($value->crossing=="over") selected='selected' @endif>crosses over</option>
										</select>

										&nbsp;&nbsp; EMA &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="emaPeriod" required="true">
											<option value="1"@if($value->emaPeriod==1) selected='selected' @endif>1</option>
											<option value="5"@if($value->emaPeriod==5) selected='selected' @endif>5</option>
											<option value="10"@if($value->emaPeriod==10) selected='selected' @endif>10</option>
											<option value="13"@if($value->emaPeriod==13) selected='selected' @endif>13</option>
											<option value="50"@if($value->emaPeriod==50) selected='selected' @endif>50</option>
											<option value="200"@if($value->emaPeriod==200) selected='selected' @endif>200</option>
											<option value="800"@if($value->emaPeriod==800) selected='selected' @endif>800</option>
										</select>
										&nbsp;&nbsp; of &nbsp;&nbsp;

										<select class="form-control currency-multiple d-inline-block w-250" name="currency[]" required="true" value="test"> 
											@foreach($currency as $currencys)
												@php ($currencies= str_replace('_','/',$currencys->currency))
												<option value="{{$currencies}}"@if($currencies==$value->currency) selected @endif>{{$currencies}}</option>
											@endforeach							
										</select>

										&nbsp;&nbsp; on &nbsp;&nbsp;

										<select class="form-control d-inline-block" name="timeFrame" required="true">
											<option value="M15"@if($value->timeFrame=="M15") selected='selected' @endif>M15</option>
											<option value="H1"@if($value->timeFrame=="H1") selected='selected' @endif>H1</option>
											<option value="H4"@if($value->timeFrame=="H4") selected='selected' @endif>H4</option>
										</select>

									</p>
								</div>
							</div>
						</div>
					
						@php ($reactive = $value->reactivateInterval)
						@php ($alertName = $value->alertName)
						@php ($alertNote = $value->alertNote) 
						@endforeach
						@php ($i=0)
						@foreach($ema_obj1 as $key=>$value)
						<div class="row condition-add-row">	
							<div class="col-12 add-row add-row1 content-row">
								<div class="content-wrap-two first">
									<p data="2">
										Condition {{$key+2}}
										<br />
										
									</p>
								</div>
								@foreach($value as $keys=>$values)
								@if($keys==0)
								<div class="content-wrap-two second">
									<input type="hidden" name="conditions[{{$i}}]" value="{{$values->alert_id}}"/>
									<input type="hidden" name="condition[{{$i}}]" value="{{$values->condition_id}}"/>
									<p>
										EMA &nbsp;&nbsp;
										<select class="form-control d-inline-block w-250" name="emaPeriod1[{{$i}}]" required="true">
											<option value="1"@if($values->emaPeriod1==1) selected='selected' @endif>1</option>
											<option value="5"@if($values->emaPeriod1==5) selected='selected' @endif>5</option>
											<option value="10"@if($values->emaPeriod1==10) selected='selected' @endif>10</option>
											<option value="13"@if($values->emaPeriod1==13) selected='selected' @endif>13</option>
											<option value="50"@if($values->emaPeriod1==50) selected='selected' @endif>50</option>
											<option value="200"@if($values->emaPeriod1==200) selected='selected' @endif>200</option>
											<option value="800"@if($values->emaPeriod1==800) selected='selected' @endif>800</option>
										</select>

										&nbsp;&nbsp; is &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="crossing2[{{$i}}]" required="true">
											<option value="Above"@if($values->crossing=="Above") selected='selected' @endif>Above</option>
											<option value="Under"@if($values->crossing=="Under") selected='selected' @endif>Under</option>
										</select>

										&nbsp;&nbsp; EMA &nbsp;&nbsp;

										
										<select class="form-control d-inline-block w-250" name="emaPeriod2[{{$i}}]" required="true">
											<option value="1"@if($values->emaPeriod2==1) selected='selected' @endif>1</option>
											<option value="5"@if($values->emaPeriod2==5) selected='selected' @endif>5</option>
											<option value="10"@if($values->emaPeriod2==10) selected='selected' @endif>10</option>
											<option value="13"@if($values->emaPeriod2==13) selected='selected' @endif>13</option>
											<option value="50"@if($values->emaPeriod2==50) selected='selected' @endif>50</option>
											<option value="200"@if($values->emaPeriod2==200) selected='selected' @endif>200</option>
											<option value="800"@if($values->emaPeriod2==800) selected='selected' @endif>800</option>
										</select>

										&nbsp;&nbsp; of &nbsp;&nbsp;

										<select class="form-control currency-multiple d-inline-block w-250"  name="currency2[{{$i}}][]" required="true">
												@foreach($currency as $currencys)
													@php ($currencies= str_replace('_','/',$currencys->currency))
													<option value="{{$currencies}}"@if($currencies==$values->currency) selected='selected' @endif>{{$currencies}}</option>
												@endforeach									
										</select>

										&nbsp;&nbsp; on &nbsp;&nbsp;

										<select class="form-control d-inline-block" name="timeFrame2[{{$i}}]" required="true">
											<option value="M15"@if($values->crossing=="M15") selected='selected' @endif>M15</option>
											<option value="H1"@if($values->crossing=="H1") selected='selected' @endif>H1</option>
											<option value="H4"@if($values->crossing=="H4") selected='selected' @endif>H4</option>
										</select>
										 &nbsp;&nbsp; 
										 @php ($i++)
									</p>
									@else
									<div id="add_field" class="row">
										<div class="col-12 add-row add-row'+n+'">
											<input type="hidden" name="condition[{{$i}}]" value='{{$values->alert_id}}'>
											<input type="hidden" name="condition[{{$i}}]" value="{{$values->condition_id}}"/>
											<p>EMA &nbsp;&nbsp; 
											
											<select class="form-control d-inline-block w-250" name="emaPeriod1[{{$i}}]" required="true">
											<option value="1"@if($values->emaPeriod1==1) selected='selected' @endif>1</option>
											<option value="5"@if($values->emaPeriod1==5) selected='selected' @endif>5</option>
											<option value="10"@if($values->emaPeriod1==10) selected='selected' @endif>10</option>
											<option value="13"@if($values->emaPeriod1==13) selected='selected' @endif>13</option>
											<option value="50"@if($values->emaPeriod1==50) selected='selected' @endif>50</option>
											<option value="200"@if($values->emaPeriod1==200) selected='selected' @endif>200</option>
											<option value="800"@if($values->emaPeriod1==800) selected='selected' @endif>800</option>
										</select> 
											&nbsp;&nbsp; is &nbsp;&nbsp; 
											<select class="form-control d-inline-block w-250"  name="crossing2[{{$i}}]">
												<option value="Above"@if($values->crossing=="Above") selected='selected' @endif>Above</option>
											<option value="Under"@if($values->crossing=="Under") selected='selected' @endif>Under</option></select>
											 &nbsp;&nbsp; EMA &nbsp;&nbsp; 
											<select class="form-control d-inline-block w-250" name="emaPeriod2[{{$i}}]" required="true">
											<option value="1"@if($values->emaPeriod2==1) selected='selected' @endif>1</option>
											<option value="5"@if($values->emaPeriod2==5) selected='selected' @endif>5</option>
											<option value="10"@if($values->emaPeriod2==10) selected='selected' @endif>10</option>
											<option value="13"@if($values->emaPeriod2==13) selected='selected' @endif>13</option>
											<option value="50"@if($values->emaPeriod2==50) selected='selected' @endif>50</option>
											<option value="200"@if($values->emaPeriod2==200) selected='selected' @endif>200</option>
											<option value="800"@if($values->emaPeriod2==800) selected='selected' @endif>800</option>
										</select> &nbsp;&nbsp; of &nbsp;&nbsp; 
												<select class="form-control currency-multiple d-inline-block w-250" name="currency2[{{$i}}][]" required="true">
												@foreach($currency as $currencys)
													@php ($currencies= str_replace('_','/',$currencys->currency))
													<option value="{{$currencies}}"@if($currencies==$values->currency) selected='selected' @endif>{{$currencies}}</option>
												@endforeach									
											</select>
												  &nbsp;&nbsp; on &nbsp;&nbsp; 
												  <select class="form-control d-inline-block" name="timeFrame2[{{$i}}]">
												  	<option value="M15"@if($values->crossing=="M15") selected='selected' @endif>M15</option>
											<option value="H1"@if($values->crossing=="H1") selected='selected' @endif>H1</option>
											<option value="H4"@if($values->crossing=="H4") selected='selected' @endif>H4</option></select> 
												  	&nbsp;&nbsp; 
												  	</p></div>
										
									</div>
									@php ($i++)
									@endif

									@endforeach
								</div>
								
							</div>					
						</div>
						
						<div class="row condition-add-row" id="add_condition">
							
						</div>
						@endforeach
										
						<div class="row select-time">
							<div class="col-12 add-row-time add-row-number1">
								<p class="mb-3">AFTER ALERT IS SENT REACTIVATE THIS ALERT AFTER &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block w-three-digi" name="reactivateInterval" placeholder="Enter Time" onkeypress="return isNumberKey(event)" required="true" value="{{ $reactive}}"> &nbsp;&nbsp; Minutes</p>
								<p>Only send alerts from</p>
							</div>
							@foreach($interval_obj as $key=>$value) 
							@if($key==0)
							<div class="col-12">
								<p>
									<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="fromInterval[1]" required="true" value="{{$value->fromInterval}}">

									 &nbsp;&nbsp; to &nbsp;&nbsp; 
						
									<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="toInterval[1]" required="true" value="{{$value->toInterval}}">
									 &nbsp;&nbsp; 
									
								</p>
							</div>
							@else					
						</div>
						<div id="add_time" class="row">
						<div class="col-12 add-row-time add-row-number'+n+'"><p>
							<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" value="{{$value->fromInterval}}"> &nbsp;&nbsp; to &nbsp;&nbsp; 
							<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" value="{{$value->toInterval}}"> &nbsp;&nbsp; </p></div>
						</div>
						@endif
						@endforeach
					</div>
						<div class="row">
							<div class="col-12">
								<p>
								Alert Name &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block" name="alertName" placeholder="Enter Alert Name" required="true" value="{{$alertName}}">
								 &nbsp;&nbsp;  Alert Note &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block" name="alertNote" placeholder="Enter Alert Note" required="true" value="{{$alertNote}}">
								</p>
							</div>
						</div>

						<div class="row">
							<div class="col-xl-2 col-lg-4 col-md-6 col-sm-12 col-12">
								<button type="submit" class="button-green btn-block edit-button">Update</button>
							</div>
						</div>
					</form>	
				</div>
			</div>			
		</div>
	</div>
</div>
<!-- Home HTML Ends Here -->
@stop
