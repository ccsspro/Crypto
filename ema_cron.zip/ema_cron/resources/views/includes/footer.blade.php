<div id='iframeloading' style='display: none; position: fixed; z-index: 9999;
background-color: rgba(0,0,0,0.2);
top: 0;
left: 0;
right: 0;
bottom: 0;'>
<img src="{{asset('images/loader1.gif')}}" style="position: absolute;
top: 50%;
left: 50%;
width: 100px;
height: 100px;
margin: -36px 0 0 -36px;">
</div>
<div class="container-fluid">
	<div class="row">
		<div class="col-12">
			<p>Copyright &copy; 2019 Dashboard, All Rights Reserved.</p>
		</div>
	</div>
</div>
<meta name="csrf-token" content="{{ csrf_token() }}">
<!-- JS -->
<script src="{{asset('js/popper.min.js')}}"></script>
<script src="{{asset('js/bootstrap.min.js')}}"></script>
<script src="{{asset('js/select2.min.js')}}"></script>
<script src="{{asset('js/mdtimepicker.min.js')}}"></script>
<!-- Custom Javascript -->
<script src="{{asset('js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('js/jquery.form-validator.min.js')}}"></script>
<!-- Custom Javascript -->
<script src="{{asset('js/custom.js')}}"></script>
<script type="text/javascript">
    form : '#entry-form'
</script>

<script>

	$(document).ready(function() {
		$('#example').DataTable({
			searching: false
		});
	} );
	
</script>
<script type="text/javascript">
	$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});
	</script>
	<script type="text/javascript">
	$('.emabtn').click(function(){
		var id =$(this).attr('id');
		$.ajax({
            type:'POST',
            url:'/alertDetails',
            data: { id : id },           			
            success:function(data) {
            	var html="";
            	var alertName="";
                var alertNote="";
            	var reactivateInterval="";
            	var client = data.client;
            	var ema = data.ema;
                var id="";
            	var interval=data.interval;
            	
                $.each(client, function(index, item) {
                	html+='<div class="row"><div class="col-12"><p><strong>Time in '+item.timeZone+'</strong></p><p>Group of events</p><p>that need to happen within &nbsp;&nbsp; <strong>'+item.scanInterval+'</strong> &nbsp;&nbsp; Minutes</p><p>WHEN Price &nbsp;&nbsp; <strong>'+item.crossing+'</strong> &nbsp;&nbsp; EMA &nbsp;&nbsp; <strong>'+item.emaPeriod+'</strong> &nbsp;&nbsp; of &nbsp;&nbsp; <strong>'+item.currency+'</strong> &nbsp;&nbsp; on &nbsp;&nbsp; <strong>'+item.timeFrame+'</strong></p>';
            		alertName=item.alertName;
                    alertNote=item.alertNote;
            		reactivateInterval=item.reactivateInterval;
                    id=item.client_id;
            	
            	});
                
            	$.each(ema, function(index, item) {
                    var n=item.length;
                    html+='<p>And <br>';
                    $.each(item, function (index, value) {

                        html+='IF EMA &nbsp;&nbsp; <strong>'+value.emaPeriod1+'</strong> &nbsp;&nbsp; is &nbsp;&nbsp; <strong>'+value.crossing+'</strong> &nbsp;&nbsp; EMA &nbsp;&nbsp; <strong>'+value.emaPeriod2+'</strong> &nbsp;&nbsp; of &nbsp;&nbsp; <strong><strong>'+value.currency+'</strong></strong> &nbsp;&nbsp; on &nbsp;&nbsp; <strong>'+value.timeFrame+'</strong>';
                        if(index!=n-1){
                            html+="<p>OR</p>"
                        }
                    })
                    //html+='IF EMA &nbsp;&nbsp; <strong>'+item.emaPeriod1+'</strong> &nbsp;&nbsp; is &nbsp;&nbsp; <strong>'+item.crossing+'</strong> &nbsp;&nbsp; EMA &nbsp;&nbsp; <strong>'+item.emaPeriod2+'</strong> &nbsp;&nbsp; of &nbsp;&nbsp; <strong><strong>'+item.currency+'</strong></strong> &nbsp;&nbsp; on &nbsp;&nbsp; <strong>'+item.timeFrame+'</strong></p>';
                   
                	//console.log(item);
                	//html+='<p>And IF EMA &nbsp;&nbsp; <strong>'+item.emaPeriod1+'</strong> &nbsp;&nbsp; is &nbsp;&nbsp; <strong>'+item.crossing+'</strong> &nbsp;&nbsp; EMA &nbsp;&nbsp; <strong>'+item.emaPeriod2+'</strong> &nbsp;&nbsp; of &nbsp;&nbsp; <strong><strong>'+item.currency+'</strong></strong> &nbsp;&nbsp; on &nbsp;&nbsp; <strong>'+item.timeFrame+'</strong></p>';         		
            	   html+="</p>";
            	});
            	html+='<p class="mb-3">AFTER ALERT IS SENT REACTIVATE THIS ALERT AFTER &nbsp;&nbsp; <strong>'+reactivateInterval+' Minutes</strong></p><p>Only send alerts from</p>';
                $.each(interval, function(index, item) {
            		//console.log(item);
                	html+='<p><strong>'+item.fromInterval+'</strong> &nbsp;&nbsp; to &nbsp;&nbsp; <strong>'+item.toInterval+'</strong></p>';         		
            	
            	});
                html+='<p>Alert Name &nbsp;&nbsp; <strong>'+alertName+'</strong>&nbsp;&nbsp;&nbsp;&nbsp;Alert Note &nbsp;&nbsp; <strong>'+alertNote+'</strong></p></div><div class="col-12"><button type="button" class="button button-red cancel_btn" id='+id+'>cancel</button></div></div>';
               // console.log(html);
                $('#model-body').html(html);

        	}
        });
     
});	
            			
            		
</script>
<!-- <script type="text/javascript">
$('.editbtn').click(function(){
        var id =$(this).attr('id');
        $.ajax({
            type:'POST',
            url:'/alertDetails',
            data: { id : id },                      
            success:function(data) {
                var html="";
                var alertName="";
                var reactivateInterval="";
                var client = data.client;
                var ema = data.ema;
                var id="";
                var interval=data.interval;
                
                $.each(client, function(index, item) {
                
                    html+='<div class="row"><div class="col-12"><p><select class="form-control d-inline-block" name="timeZone" id="timeZone" required="true"><option value="Europe-London">London, UK</option><option value="Europe-Berlin">Berlin, Germany (GMT+1)</option><option value="America-New_York">New York, NY, USA (GMT-5)</option><p></select></p></div><div class="col-12"><p>Group of events</p>that need to happen within &nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" placeholder="Enter Time" name="scanInterval" onkeypress="return isNumberKey(event)" required="true" value="'+item.scanInterval+'"> &nbsp;&nbsp; Minutes</p></div><div class="row condition-add-row"><div class="col-12 content-row"><div class="content-wrap-one first"><p>Condition 1</p></div><div class="content-wrap-one second"><p>CLOSE PRICE &nbsp;&nbsp;<select class="form-control d-inline-block w-250" name="crossing" required="true"><option value="" disabled selected>crosses under/crosses over</option><option value="under">crosses under</option><option value="over">crosses over</option></select>&nbsp;&nbsp; EMA &nbsp;&nbsp;<input type="text" class="form-control d-inline-block" name="emaPeriod" placeholder="Enter period" maxlength="3" onkeypress="return isNumberKey(event)" required="true">&nbsp;&nbsp; of &nbsp;&nbsp;';
                        alertName=item.alertName;
                        reactivateInterval=item.reactivateInterval;
                        id=item.client_id;
                
                });
                
                $.each(ema, function(index, item) {
                    var n=item.length;
                    html+='<p>And <br>';
                    $.each(item, function (index, value) {

                        html+='IF EMA &nbsp;&nbsp; <strong>'+value.emaPeriod1+'</strong> &nbsp;&nbsp; is &nbsp;&nbsp; <strong>'+value.crossing+'</strong> &nbsp;&nbsp; EMA &nbsp;&nbsp; <strong>'+value.emaPeriod2+'</strong> &nbsp;&nbsp; of &nbsp;&nbsp; <strong><strong>'+value.currency+'</strong></strong> &nbsp;&nbsp; on &nbsp;&nbsp; <strong>'+value.timeFrame+'</strong>';
                        if(index!=n-1){
                            html+="<p>OR</p>"
                        }
                    })
                    //html+='IF EMA &nbsp;&nbsp; <strong>'+item.emaPeriod1+'</strong> &nbsp;&nbsp; is &nbsp;&nbsp; <strong>'+item.crossing+'</strong> &nbsp;&nbsp; EMA &nbsp;&nbsp; <strong>'+item.emaPeriod2+'</strong> &nbsp;&nbsp; of &nbsp;&nbsp; <strong><strong>'+item.currency+'</strong></strong> &nbsp;&nbsp; on &nbsp;&nbsp; <strong>'+item.timeFrame+'</strong></p>';
                   
                    //console.log(item);
                    //html+='<p>And IF EMA &nbsp;&nbsp; <strong>'+item.emaPeriod1+'</strong> &nbsp;&nbsp; is &nbsp;&nbsp; <strong>'+item.crossing+'</strong> &nbsp;&nbsp; EMA &nbsp;&nbsp; <strong>'+item.emaPeriod2+'</strong> &nbsp;&nbsp; of &nbsp;&nbsp; <strong><strong>'+item.currency+'</strong></strong> &nbsp;&nbsp; on &nbsp;&nbsp; <strong>'+item.timeFrame+'</strong></p>';                 
                   html+="</p>";
                });
                html+='<p class="mb-3">AFTER ALERT IS SENT REACTIVATE THIS ALERT AFTER &nbsp;&nbsp; <strong>'+reactivateInterval+' Minutes</strong></p><p>Only send alerts from</p>';
                $.each(interval, function(index, item) {
                    //console.log(item);
                    html+='<p><strong>'+item.fromInterval+'</strong> &nbsp;&nbsp; to &nbsp;&nbsp; <strong>'+item.toInterval+'</strong></p>';                
                
                });
                html+='<p>Alert Name &nbsp;&nbsp; <strong>'+alertName+'</strong></p></div><div class="col-12"><button type="button" class="button button-red cancel_btn" id='+id+'>cancel</button></div></div>';
               // console.log(html);
                $('#model-body').html(html);

            }
        });
     
});  
</script> -->

<script type="text/javascript">
    $('.duplicate').click(function(){
        var id =$(this).attr('id');
        $.ajax({
            type:'POST',
            url:'/duplicateDetails',
            data: { id : id },                      
            success:function(data) {
                location.reload();
            }
        });   
    }); 
                        
                    
</script>

<script type="text/javascript">
    $('.editbtn').click(function(){
        var id =$(this).attr('id');
         
    }); 

</script>

<script type="text/javascript">
    $(document).on("click", ".cancel_btn", function(event){
        var id =$(this).attr('id');
        var confirmation = confirm("are you sure you want to cancel the alert?");
        if(confirmation){
            $.ajax({
            type:'POST',
            url:'/cancelAlert',
            data: { id : id },                      
            success:function(data) {
                location.reload();
            }
        }); 
        }
         
    }); 
                        
                    
</script>
<script>
// Required Number				
function isNumberKey(evt){
	var charCode = (evt.which) ? evt.which : event.keyCode
	if (charCode > 31 && (charCode < 48 || charCode > 57))
		return false;
	return true;
}		
</script>
