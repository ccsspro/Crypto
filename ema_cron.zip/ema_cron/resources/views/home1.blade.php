@extends('layouts.app')
@section('content')
<!-- Home HTML Starts Here  -->
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="content-wrap">
					<form name="entry-form" id="entry-form">
						{{ csrf_field() }}
						<div class="row">
							<div class="col-12">
								<p>
									<select class="form-control d-inline-block" name="timeZone" required="true">
										<option value="" disabled selected>Select Timezone</option>
										<option value="Europe-London">London, UK</option>
										<option value="Europe-Berlin">Berlin, Germany (GMT+1)</option>
										<option value="America-New_York">New York, NY, USA (GMT-4)</option>
							<p>
										</select>
								</p>
							</div>
							<div class="col-12">
								<p>Group of events</p>
									that need to happen within &nbsp;&nbsp; 
									<input type="text" class="form-control d-inline-block w-three-digi" placeholder="Enter Time" name="scanInterval" onkeypress="return isNumberKey(event)" required="true"> &nbsp;&nbsp; Minutes
								</p>
							</div>
						</div>
						
						<div class="row condition-add-row">
							<div class="col-12 content-row">
								<div class="content-wrap-one first">
									<p>
										Condition 1

									</p>
								</div>
								<div class="content-wrap-one second">
									<p>
										CLOSE PRICE &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="crossing" required="true">
											<option value="" disabled selected>crosses under/crosses over</option>
											<option value="under">crosses under</option>
											<option value="over">crosses over</option>
										</select>

										&nbsp;&nbsp; EMA &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="emaPeriod" required="true">
											<option value="" disabled selected>Select Period</option>
											<option value="1">1</option>
											<option value="5">5</option>
											<option value="10">10</option>
											<option value="13">13</option>
											<option value="50">50</option>
											<option value="200">200</option>
											<option value="800">800</option>
										</select>

										&nbsp;&nbsp; of &nbsp;&nbsp;

										<select class="form-control currency-multiple d-inline-block w-250" multiple="multiple" name="currency[]" required="true">
											@foreach($currency as $currencys)
												@php ($currencies= str_replace('_','/',$currencys->currency))
												<option value="{{$currencies}}">{{$currencies}}</option>
											@endforeach
										</select>

										&nbsp;&nbsp; on &nbsp;&nbsp;

										<select class="form-control d-inline-block" name="timeFrame" required="true">
											<option value="" disabled selected>Timeframe</option>
											<option value="M15">M15</option>
											<option value="H1">H1</option>
											<option value="H4">H4</option>
										</select>

									</p>
								</div>
							</div>
						</div>
						<div class="row condition-add-row">	
							<div class="col-12 add-row add-row1 content-row">
								<div class="content-wrap-two first">
									<p data="2">
										Condition 2
										<br />
										<a class="add-condition-new button-blue" data="1">Add Condition</a>
										
									</p>
								</div>
								<div class="content-wrap-two second">
									<input type="hidden" name="condition" value="2"/>
									<p>
										EMA &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="emaPeriod1" required="true">
											<option value="" disabled selected>Select Period</option>
											<option value="1">1</option>
											<option value="5">5</option>
											<option value="10">10</option>
											<option value="13">13</option>
											<option value="50">50</option>
											<option value="200">200</option>
											<option value="800">800</option>
										</select>
										&nbsp;&nbsp; is &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="crossing2" required="true">
											<option value="">Select Above or Under</option>
											<option value="Above">Above</option>
											<option value="Under">Under</option>
										</select>

										&nbsp;&nbsp; EMA &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="emaPeriod2" required="true">
											<option value="" disabled selected>Select Period</option>
											<option value="1">1</option>
											<option value="5">5</option>
											<option value="10">10</option>
											<option value="13">13</option>
											<option value="50">50</option>
											<option value="200">200</option>
											<option value="800">800</option>
										</select>


										&nbsp;&nbsp; of &nbsp;&nbsp;

										<select class="form-control currency-multiple d-inline-block w-250" multiple="multiple" name="currency2" required="true">
											@foreach($currency as $currencys)
												@php ($currencies= str_replace('_','/',$currencys->currency))
												<option value="{{$currencies}}">{{$currencies}}</option>
											@endforeach											
										</select>

										&nbsp;&nbsp; on &nbsp;&nbsp;

										<select class="form-control d-inline-block" name="timeFrame2" required="true">
											<option value="" disabled selected>Timeframe</option>
											<option value="M15">M15</option>
											<option value="H1">H1</option>
											<option value="H4">H4</option>
										</select>
										 &nbsp;&nbsp; 
										<a class="add-button-new plus-button" id="2" data="1"></a>

									</p>
									<div id="add_field" class="row"></div>
								</div>
							</div>					
						</div>
						<div class="row condition-add-row" id="add_condition">
							
						</div>
						
						
										
						<div class="row select-time">
							<div class="col-12 add-row-time add-row-number1">
								<p class="mb-3">AFTER ALERT IS SENT REACTIVATE THIS ALERT AFTER &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block w-three-digi" name="reactivateInterval" placeholder="Enter Time" onkeypress="return isNumberKey(event)" required="true"> &nbsp;&nbsp; Minutes</p>
								<p>Only send alerts from</p>
							</div>
							<div class="col-12">
								<p>
									<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="fromInterval" required="true" id="fromInterval">

									 &nbsp;&nbsp; to &nbsp;&nbsp; 
						
									<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="toInterval" required="true" id="toInterval">
									 &nbsp;&nbsp; 
									<a class="add-time plus-button"></a>
								</p>
							</div>					
						</div>
						<div id="add_time" class="row"></div>
						
						<div class="row">
							<div class="col-12">
								<p>
								Alert Name &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block fromInterval" name="alertName" placeholder="Enter Alert Name" required="true">
								 &nbsp;&nbsp;  Alert Note &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block toInterval" name="alertNote" placeholder="Enter Alert Note" required="true">
								</p>
							</div>
						</div>

						<div class="row">
							<div class="col-xl-2 col-lg-4 col-md-6 col-sm-12 col-12">
								<button type="button" class="button-green btn-block submit-button">Submit</button>
							</div>
						</div>
					</form>	
				</div>
			</div>			
		</div>
	</div>
</div>
<!-- Home HTML Ends Here -->
<script type="text/javascript">
	$( "#toInterval" ).change(function() {
    	var start_time = $("#fromInterval").val();
		var end_time = $("#toInterval").val();
		var stt = new Date("November 13, 2013 " + start_time);
		stt = stt.getTime();

		var endt = new Date("November 13, 2013 " + end_time);
		endt = endt.getTime();
		console.log("Time1: "+ stt + " Time2: " + endt);

		if(stt > endt) {
			alert("Start-time must be smaller then End-time.");
    		$("#toInterval").val('');
        	return false;
		}
	});
</script>
@stop
