<!doctype html>
<html lang="en">
<head>
     @include('includes.head')
</head>
<body class="pushmenu-push">
    <div class="wrapper">
        <!-- Header HTML Starts Here -->
        <header>
            @include('includes.header')
        </header>
         @yield('content')
         <!-- Footer  HTML Starts Here -->
        <footer>
            @include('includes.footer')
        </footer>
        <!-- Footer HTML Ends Here -->
    </div>
    <!-- Wrapper Ends -->
</body>
</html>
