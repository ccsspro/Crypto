<div class="container">
    <div class="row">
       
  @foreach($ema as $value) 
                        <div class="col-md-3">
                        <table>
                            <tr><td>Currency</td><td>{{ $value[4] }} </td></tr>
                            <tr><td>Time Frame </td><td> {{$value[6]}} </td></tr>
                            <tr><td>Price</td><td>{{ $value[1] }}</td></tr>
                            <tr><td>EMA {{ $value[5] }} </td><td> {{ $value[0] }} </td></tr>
                            <tr><td>High {{ $value[2] }}</td><td> Low {{ $value[3] }} </td></tr>
                            <tr><td colspan=2>
                                @if($value[1]>$value[0])
                                    Price Crossover EMA {{ $value[5] }}
                                @endif
                                @if($value[1]<$value[0])
                                    Price Crossunder EMA {{ $value[5] }}
                                @endif
                                @if($value[1]==$value[0])
                                    Price Crossing EMA {{ $value[5] }}
                                @endif
                            </td></tr>
                        </table>
                    </div>
            
                
            @endforeach
        </div>
   {{-- <div class="row">        
          @for($i=0;$i < count($ema1);$i++)
              <div class="col-md-3">
      
      
                          <table>
                              <tr><td>Currency</td><td>{{ $ema1[$i][4] }} </td></tr>
                              <tr><td>Time Frame </td><td> {{$ema1[$i][6]}} </td></tr>
                              <tr><td>EMA {{ $ema1[$i][5] }} </td><td> {{ $ema1[$i][0] }} </td></tr>
                              <tr><td>EMA {{ $ema2[$i][5] }} </td><td> {{ $ema2[$i][0] }} </td></tr>
                               <tr><td colspan=2>
                                  @if($ema1[$i][0]>$ema2[$i][0])
                                      EMA {{ $ema1[$i][5] }} Above EMA {{ $ema2[$i][5] }}
                                  @endif
                                   @if($ema1[$i][0]<$ema2[$i][0])
                                      EMA {{ $ema1[$i][5] }} Under EMA {{ $ema2[$i][5] }}
                                  @endif
                                  @if($ema1[$i][0]==$ema2[$i][0])
                                      EMA {{ $ema1[$i][5] }} on EMA {{ $ema2[$i][5] }}
                                  @endif
                              </td></tr>
                          </table>
                          </div>
          @endfor
      
           </div>--}}
                   
            

         
                 
    </div> 
    
    
</div>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">


