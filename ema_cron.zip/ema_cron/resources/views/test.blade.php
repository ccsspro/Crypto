								<table border=1>
									<thead>
										<tr>
											<td>EUR_USD</td>
											<td>America-New_York</td>
											<td>H1</td>
											<td>EMA 50 </td>
										</tr>
										<tr>
											<th>Time</th>
											<th>Price</th>
											<th>Calc 1</th>
											<th>Calc 2</th>
										</tr>
									</thead>
									<tbody>
										@foreach($test_obj as $key=>$value)
										<tr>
											<td>{{$value->time}}</td>
											<td>{{$value->price}}</td>
											<td>{{$value->ema}}</td>
											<td>{{$value->ema1}}</td>

											
										</tr>
										@endforeach
									</tbody>
								</table>
<script src="js/jquery.js"></script>								
<script src="js/common.js"></script>