<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;
use App\Helpers\AppHelper;
use \App\Model\Ema;
use \App\Model\Client;
use \App\Model\Interval;
use \App\Model\Test;
use \App\Model\Trend;
use \App\Model\Alert;
use \App\Model\Currency;
use \App\Model\Condition;
use \App\Model\Primary;
use \App\Model\Secondary;
use \App\Model\Conditions;


class secondarycheck extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'secondary:check';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Secondary Check';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /*
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {/*
        $client_obj = Client::where('alertStatus', 1)->orderby('client_id','desc')->get();
        foreach($client_obj as $client_objs){
            if((date("Y-m-d H:i:s", strtotime($client_objs->started_at . "+".$client_objs->reactivateInterval."minutes"))) >= (date('Y-m-d H:i:s'))){
                if($client_objs->status==1){
                    if((date("Y-m-d H:i:s", strtotime($client_objs->scan_start . "+".$client_objs->scanInterval."minutes"))) > (date('Y-m-d H:i:s'))){
                        $timeZone=str_replace('-','%2F',$client_objs->timeZone);
                        $ema_obj=Ema::where('client_id',$client_objs->client_id)->where('status',0)->get();
                        foreach ($ema_obj as $value){
                            $currencys=explode(",",$value->currency);
                            $condition=$value->crossing;
                            
                            foreach ($currencys as $currency) {
                                $currency=str_replace("/", "_", $currency);
                                $alertObj=Condition::where('alertId', $value->alert_id)->where('currency',$currency)->first();
                                //print_r($alertObj);
                                if($alertObj){
                                    if($alertObj->status!=1){
                                        $ema1=AppHelper::getEMA($value->emaPeriod1,$currency,$value->timeFrame,$timeZone);      
                                        $ema2=AppHelper::getEMA($value->emaPeriod2,$currency,$value->timeFrame,$timeZone);
                                    }else{
                                        break;
                                    }
                                }else{
                                    $alertObj= new Condition();
                                    $alertObj->alertId=$value->alert_id;
                                    $alertObj->condition_id=$value->condition_id;
                                    $alertObj->currency=$currency;
                                    $alertObj->save();
                                    $ema1=AppHelper::getEMA($value->emaPeriod1,$currency,$value->timeFrame,$timeZone);      
                                    $ema2=AppHelper::getEMA($value->emaPeriod2,$currency,$value->timeFrame,$timeZone);
                                }
                                $emaobj=Secondary::where('alertId',$alertObj->id)->first();
                                if($emaobj){
                                    $emaobj->ema1=$ema1[0];
                                    $emaobj->ema2=$ema2[0];
                                    $emaobj->save();
                                }else{
                                    $emaobj=new Secondary();
                                    $emaobj->alertId=$alertObj->id;
                                    $emaobj->ema1=$ema1[0];
                                    $emaobj->ema2=$ema2[0];
                                    $emaobj->save();
                                }

                                if($condition=="Above"){
                                    if($ema1[0]>$ema2[0]){
                                        $alertObj->status=1;
                                        $alertObj->save();
                                    }
                                }
                                if($condition=="Under"){
                                    if($ema1[0]<$ema2[0]){
                                        $alertObj->status=1;
                                        $alertObj->save();
                                    }
                                } 
                            }
                        }
                    }        
                }
            }           
        }*/
    }
}
