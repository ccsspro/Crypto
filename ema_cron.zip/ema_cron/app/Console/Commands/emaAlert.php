<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;
use App\Helpers\AppHelper;
use \App\Model\Trend;
use \App\Model\Ema;
use \App\Model\Client;
use \App\Model\Interval;
use \App\Model\Test;
use \App\Model\Alert;
use \App\Model\Currency;
use \App\Model\Condition;


class emaAlert extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ema:alert';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Ema Alert';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /*
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle(){ 
        //$status=AppHelper::sendMessage('-386420414', "Test Message", false, 1, false);  
        $client_obj = Client::where('alertStatus', 1)->orderby('client_id','desc')->get();
        foreach($client_obj as $client_objs){
            if((date("Y-m-d H:i:s", strtotime($client_objs->created_at . "+".$client_objs->scanInterval."minutes"))) > (date('Y-m-d H:i:s'))){
                $timeZone=str_replace('-','%2F',$client_objs->timeZone) ;
                $condition_obj1=Condition::selectRaw('alertId, sum(status) as s,count(*) as c')->groupBy('alertId')->having('s','<>','c')->get();
                $ema=array();
                foreach ($condition_obj1 as $key => $value) {
                    if($value->alertId==$client_objs->client_id){
                        $currency=explode(",",$client_objs->currency);
                        $scanInterval=$client_objs->emaPeriod;
                        $timeFrame=$client_objs->timeFrame;
                        $condition=$client_objs->crossing;
                        foreach($currency as $currencies){
                            $currency2=str_replace("/", "_", $currencies);
                            $alertObj=Alert::where('alertName', $client_objs->alertName)->where('currency',$currency2)->first();
                            if($alertObj){
                                if((date("Y-m-d H:i:s", strtotime($alertObj->created_at . "+".$client_objs->reactivateInterval."minutes"))) < (date('Y-m-d H:i:s'))){
                                    $ema[]=AppHelper::getEMA($scanInterval,$currency2,$timeFrame,$timeZone);
                                    $alertObj->created_at=date('Y-m-d H:i:s');
                                    $status=$alertObj->save();
                                }else{
                                    break;
                                }
                            }else{
                                $ema[]=AppHelper::getEMA($scanInterval,$currency2,$timeFrame,$timeZone);
                                $altobj = new Alert();
                                $altobj->alertName = $client_objs->alertName;
                                $altobj->currency  = $currency2;
                                $altobj->save();
                            }
                        }
                        $icon1=AppHelper::getEmoji('\xF0\x9F\x94\xB5');
                        $icon2=AppHelper::getEmoji('\xF0\x9F\x94\xB4');
                        $cur=AppHelper::getEmoji('\xF0\x9F\x92\xB0');
                        $loc=AppHelper::getEmoji('\xF0\x9F\x93\x8D');
                        $hod=AppHelper::getEmoji('\xF0\x9F\x93\x88');
                        $lod=AppHelper::getEmoji('\xF0\x9F\x93\x89');
                        $news=AppHelper::getEmoji('\xF0\x9F\x93\xB0');
                        $chk=AppHelper::getEmoji('\xF0\x9F\x94\x96');
                        foreach ($ema as $value) {
                            $cross="";
                            $text="";
                            if($value[1]>=$value[0]){
                                $text=$icon1.' BUY '.$icon1.chr(10);
                                $cross="over";
                            }
                            if($value[1]<$value[0]){
                                $text=$icon2.' SELL '.$icon2.chr(10);
                                $cross="under";
                            }
                            $text.=$cur.'Currency : '.$value[4].chr(10);
                            $text.=$loc.'Location : EMA  '.$value[5].chr(10);
                            $text.=$hod.'HOD :'.$value[2].chr(10);
                            $text.=$lod.'LOD :'.$value[3].chr(10);
                            $text.=$news.'NEWS : <a href="https://www.forexfactory.com/calendar.php">Forex Factory</a>'.chr(10); 
                            $text.=$chk.$client_objs->alertNote.chr(10);
                            if($cross==$condition){
                                $obj = Trend::where('coin',$value[4])->where('alert',$client_objs->client_id)->first();
                                if($obj){
                                    if($cross=!$obj->trend){
                                        $status=AppHelper::sendMessage('-386420414', $text, false, 1, false); 
                                        $status=AppHelper::sendMessage('-1001162032776', $text, false, 1, false);
                                        $obj->trend=$cross;
                                        $obj->save();
                                    }
                                }else{
                                    $obj1=new Trend();
                                    $obj1->coin=$value[4];
                                    $obj1->alert=$client_objs->client_id;
                                    $obj1->trend=$cross;
                                    $obj1->save();
                                    $status=AppHelper::sendMessage('-386420414', $text, false, 1, false); 
                                    $status=AppHelper::sendMessage('-1001162032776', $text, false, 1, false);
                                }
                            }
                        } 
                    }
                }    
            }
            else{
                $client_objs->created_at=date('Y-m-d H:i:s');
                $client_objs->save();
                $obj=Condition::where('alertId', $client_objs->client_id)->get();
                foreach($obj as $value){
                    $value->status=0;
                    $value->save();
                }
            }
        }    
    }
}
