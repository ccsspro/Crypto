<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Ixudra\Curl\Facades\Curl;
use App\Helpers\AppHelper;
use \App\Model\Ema;
use \App\Model\Client;
use \App\Model\Interval;
use \App\Model\Test;
use \App\Model\Trend;
use \App\Model\Alert;
use \App\Model\Currency;
use \App\Model\Condition;
use \App\Model\Primary;
use \App\Model\Secondary;
use \App\Model\Conditions;


class primarycheck extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'primary:check';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Primary Check';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /*
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {/*
        
        $client_obj = Client::where('alertStatus', 1)->orderby('client_id','desc')->get();
        $trend="";
        foreach($client_obj as $client_objs){
            if((date("Y-m-d H:i:s", strtotime($client_objs->started_at . "+".$client_objs->reactivateInterval."minutes"))) >= (date('Y-m-d H:i:s'))){
                if((date("Y-m-d H:i:s", strtotime($client_objs->scan_start . "+".$client_objs->scanInterval."minutes"))) > (date('Y-m-d H:i:s'))){
                    $currency=explode(",",$client_objs->currency);
                    $scanInterval=$client_objs->emaPeriod;
                    $timeFrame=$client_objs->timeFrame;
                    $condition=$client_objs->crossing;
                    $timeZone=str_replace('-','%2F',$client_objs->timeZone);
                    foreach($currency as $currencies){
                        $currency=str_replace("/", "_", $currencies);
                        $alertObj=Alert::where('alertId', $client_objs->client_id)->where('currency',$currency)->first();
                        if($alertObj){    
                            $ema=AppHelper::getEMA($scanInterval,$currency,$timeFrame,$timeZone);
                        }else{
                            $alertObj= new Alert();
                            $alertObj->alertId=$client_objs->client_id;
                            $alertObj->currency=$currency;
                            $alertObj->plotting=0;
                            $alertObj->save();
                            $ema=AppHelper::getEMA($scanInterval,$currency,$timeFrame,$timeZone);
                            if($ema[1]>$ema[0]){
                                $alertObj->prime="over";
                                $alertObj->save();
                            }
                            else{
                                $alertObj->prime="under";
                                $alertObj->save();
                            }
                        }
                        $emaobj=Primary::where('alertId',$client_objs->client_id)->first();
                        if($emaobj){
                            $emaobj->price=$ema[1];
                            $emaobj->ema=$ema[0];
                            $emaobj->save();
                        }else{                      
                            $emaobj=new Primary();
                            $emaobj->alertId=$client_objs->client_id;
                            $emaobj->price=$ema[1];
                            $emaobj->ema=$ema[0];
                            $emaobj->save();
                        }

                        if($ema[1]>$ema[0]){
                            $trend="over";
                        }
                        else{
                            $trend="under";
                        }
                        if($trend!=$alertObj->prime){
                            $alertObj->prime=$trend;
                            $alertObj->save();
                            if($condition==$trend){
                                print_r("TEST1");
                                if($alertObj->plotting==0){
                                    $alertObj->plotting=1;
                                    $alertObj->status=1;
                                    $alertObj->save();
                                }
                            }                  
                        }
                    }
                }else{
                    $client_objs->scan_start=date('Y-m-d H:i:s');
                    $client_objs->status=0;
                    $client_objs->save();
                    $status=DB::table('alertLog')->where('alertId',$client_objs->client_id)->delete();
                    $condition=EMA::where('client_id',$client_objs->client_id)->get();
                    if(count($condition)>0){
                        foreach($condition as $value){
                            $value->status=0;
                            $value->save();
                            $alertObj=Condition::where('alertId', $value->alert_id)->first();
                            if($alertObj){
                                $alertObj->status=0;
                                $alertObj->save();
                            }
                            $status=DB::table('conditionLog')->where('alertId',$value->client_id)->delete();
                        }   
                    }
                }
            }else{
                $client_objs->started_at=date('Y-m-d H:i:s');
                $client_objs->scan_start=date('Y-m-d H:i:s');
                $client_objs->status=0;
                $client_objs->save();
                $status=DB::table('alertLog')->where('alertId',$client_objs->client_id)->delete();
                $trend=Trend::where('alert',$client_objs->client_id)->get();
                if(count($trend)>0){
                    $status=DB::table('trend')->where('alert',$client_objs->client_id)->delete();
                }
                
                $condition=EMA::where('client_id',$client_objs->client_id)->get();
                if(count($condition)>0){
                    foreach($condition as $value){
                        $value->status=0;
                        $value->save();
                        $alertObj=Condition::where('alertId', $value->alert_id)->first();
                        if($alertObj){
                            $alertObj->status=0;
                            $alertObj->save();
                        }
                        $status=DB::table('conditionLog')->where('alertId',$value->client_id)->delete();
                    }   
                }    
            }
        }*/
    }
}
