<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;
use App\Helpers\AppHelper;
use \App\Model\Ema;
use \App\Model\Client;
use \App\Model\Interval;
use \App\Model\Test;
use \App\Model\Trend;
use \App\Model\Alert;
use \App\Model\Currency;
use \App\Model\Condition;
use \App\Model\Primary;
use \App\Model\Secondary;
use \App\Model\Conditions;


class sendmessage extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send:message';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Message';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /*
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    { /* 
        $icon1=AppHelper::getEmoji('\xF0\x9F\x94\xB5');
        $icon2=AppHelper::getEmoji('\xF0\x9F\x94\xB4');
        $cur=AppHelper::getEmoji('\xF0\x9F\x92\xB0');
        $loc=AppHelper::getEmoji('\xF0\x9F\x93\x8D');
        $hod=AppHelper::getEmoji('\xF0\x9F\x93\x88');
        $lod=AppHelper::getEmoji('\xF0\x9F\x93\x89');
        $news=AppHelper::getEmoji('\xF0\x9F\x93\xB0');
        $chk=AppHelper::getEmoji('\xF0\x9F\x94\x96');

        $client_obj = Client::where('client_preference.status',1)->join('alertLog', 'client_preference.client_id','=','alertLog.alertId')->join('primary_values','alertLog.alertId','=','primary_values.alertId')->get();
        foreach ($client_obj as $value) {
            $f=0;
            $ema_obj= Ema::where('client_id',$value->client_id)->get();
            foreach ($ema_obj as $values) {
                if($values->status==1){
                    $f++;
                }
            }
            if($f==count($ema_obj)){
                if($value->crossing=="over")
                {
                    $text=$icon1.' BUY '.$icon1.chr(10);
                }
                if($value->crossing=="under"){
                    $text=$icon2.' SELL '.$icon2.chr(10);
                }
                
                $timeZone=str_replace('-','%2F',$value->timeZone);
               // print_r($value->timeFrame);die;
                $ema=AppHelper::getEMA($value->emaPeriod,$value->currency,$value->timeFrame,$timeZone);
                $text.=$cur.'Currency : '.$value->currency.chr(10);
                $text.=$loc.'Location : EMA  '.$value->emaPeriod.chr(10);
                $text.=$hod.'HOD :'.$ema[2].chr(10);
                $text.=$lod.'LOD :'.$ema[3].chr(10);
                $text.=$news.'NEWS : <a href="https://www.forexfactory.com/calendar.php">Forex Factory</a>'.chr(10); 
                $text.=$chk.$value->alertNote.chr(10);
                $obj = Trend::where('coin',$value->currency)->where('alert',$value->client_id)->first();
                //print_r($obj);die;
                if($obj){
                    if((date("Y-m-d H:i:s", strtotime($obj->scan_start . "+".$value->reactivateInterval."minutes"))) > (date('Y-m-d H:i:s'))){
                        if($value->crossing=!$obj->trend){
                            $status=AppHelper::sendMessage('-386420414', $text, false, 1, false); 
                            $status=AppHelper::sendMessage('-1001162032776', $text, false, 1, false);
                            //print_r($text);
                            $obj->trend=$value->crossing;
                            $obj->save();
                        }
                    }
                }else{
                    $obj1=new Trend();
                    $obj1->coin=$value->currency;
                    $obj1->alert=$value->client_id;
                    $obj1->trend=$value->crossing;
                    $obj1->save();
                    //print_r($text);
                    $status=AppHelper::sendMessage('-386420414', $text, false, 1, false); 
                    $status=AppHelper::sendMessage('-1001162032776', $text, false, 1, false);
                }
            }
        }*/
        $status=AppHelper::sendMessage1('-1250130705', "TEST ALERT", false, 1, false);

    }
}
