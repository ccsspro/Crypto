<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;
use App\Helpers\AppHelper;
use \App\Model\Trend;
use \App\Model\Ema;
use \App\Model\Client;
use \App\Model\Interval;
use \App\Model\Test;
use \App\Model\Alert;
use \App\Model\Currency;
use \App\Model\Condition;


class crossOver extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cross:over';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cross Over';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /*
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {  
       // AppHelper::sendMessage('-386420414', "Test MESSAGE", false, 1, false);
       /* $currencyFlag=0;
        $subCondition=0;
        $conditionFlag=0;
        
       // $status=AppHelper::sendMessage('-386420414', "TEST MESSAGE", false, 1, false); 
        $client_obj = Client::where('alertStatus', 1)->orderby('client_id','desc')->get();

        foreach($client_obj as $client_objs){
            $flg=1;
            $shift=Interval::where('client_id',$client_objs->client_id)->get();
            if($flg==1){
                if((date("Y-m-d H:i:s", strtotime($client_objs->created_at . "+".$client_objs->scanInterval."minutes"))) > (date('Y-m-d H:i:s'))){
                    $timeZone=str_replace('-','%2F',$client_objs->timeZone) ;
                    $alert= Ema::where('client_id',$client_objs->client_id)->orderby('condition_id','desc')->first();
                    for($i=2;$i<=$alert->condition_id;$i++){
                       $ema_obj[]=Ema::where('client_id',$client_objs->client_id)->where('condition_id',$i)->get();
                    }
                    foreach ($ema_obj as $key => $value) {
                       foreach ($value as $key => $values) {
                            $currency3=explode(",",$values->currency);
                            foreach($currency3 as $currency){
                                $currency=str_replace("/", "_", $currency);  
                                $ema1=AppHelper::getEMA($values->emaPeriod1,$currency,$values->timeFrame,$timeZone);      
                                $ema2=AppHelper::getEMA($values->emaPeriod2,$currency,$values->timeFrame,$timeZone);
                                if($values->crossing=="Above"){
                                    if($ema1[0]>=$ema2[0]){
                                        $currencyFlag=1;
                                    }else{
                                        $currencyFlag=0;
                                        break;
                                    }   
                                }
                                if($values->crossing=='Under'){
                                    if($ema1[0]<$ema2[0]){
                                        $currencyFlag=1;
                                    }else{
                                        $currencyFlag=0;
                                        break;
                                    }
                                }
                            }
                           // print_r($currencyFlag);
                            if($currencyFlag==1){
                                $subCondition=1;
                                $condition_obj=Condition::where('alertId',$client_objs->client_id)->where('conditionId',$values->condition_id)->first();
                                if($condition_obj){//print_r($condition_obj);
                                    $condition_obj->status=1;
                                    $condition_obj->save();
                                }
                            }    
                        }
                    
                        if($subCondition==1){
                            $conditionFlag=1;
                        }else{
                            $conditionFlag=0;
                        }   
                    }               
                }
            }
        }*/    
    }
}
