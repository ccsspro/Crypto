<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;
use App\Helpers\AppHelper;
use \App\Model\Trend;

class priceAlert extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'price:alert';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Price Alert';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /*
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {   
        $currency="EUR_USD,EUR_JPY,USD_JPY,GBP_USD";
        $currency1=explode(",",$currency);
        $period="M15";
        $timeZone="America%2FNew_York";
        $trend="";
        $obj = Trend::orderby('id','desc')->first();
        $trends=explode(",",$obj->trend);
        foreach($currency1 as $index=>$currency){
            $ema1=AppHelper::getEMA(1,$currency,$period,$timeZone);      
            $ema2=AppHelper::getEMA(13,$currency,$period,$timeZone);
            if($ema1[0]>$ema2[0]){
                $trend="Above";
                $text=$currency.chr(10);
                $text.= 'EMA1 Crosses above EMA13 on the M15 timeframe'.chr(10);
                //status=AppHelper::sendMessage('-386420414', $text, false, 1, false); 
            }else{
                $trend="Under";
                $text=$currency.chr(10);
                $text.= 'EMA 1 Crosses under EMA13 on the M15 timeframe'.chr(10);
            }

            if($trend!=$trends[$index]){
                //$status=AppHelper::sendMessage('-386420414', $text, false, 1, false);
                //$status=AppHelper::sendMessage('-1001162032776', $text, false, 1, false);
            }
           $new[]=$trend;
            
        }
        
        $trend=implode(",", $new);
        $obj->trend=$trend;
        $obj->save();
    }
}
