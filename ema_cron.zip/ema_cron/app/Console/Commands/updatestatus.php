<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;
use App\Helpers\AppHelper;
use \App\Model\Ema;
use \App\Model\Client;
use \App\Model\Interval;
use \App\Model\Test;
use \App\Model\Trend;
use \App\Model\Alert;
use \App\Model\Currency;
use \App\Model\Condition;
use \App\Model\Primary;
use \App\Model\Secondary;
use \App\Model\Conditions;

class updatestatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'update:status';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update Status';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /*
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    { /*
        $client=Alert::selectRaw('alertId, sum(status) as s,count(*) as c')->groupBy('alertId')->having('s','<>','c')->get();
        foreach ($client as $value) {
            $obj=Client::where('client_id',$value->alertId)->first();   
            $obj->status=1;
            $obj->save();
        }
        $condition_obj=Condition::selectRaw('alertId, sum(status) as s,count(*) as c')->groupBy('alertId')->having('s','<>','c')->get();
        foreach ($condition_obj as $value) {
            $obj=Conditions::where('alertId',$value->alertId)->first();   
            $obj->status=1;
            $obj->save();
        }
        $condition= Conditions::selectRaw('client_id,conditionId, sum(status) as s')->groupBy('client_id','conditionId')->having('s','>',0)->get();
        foreach($condition as $value){
            $ema=EMA::where('condition_id',$value->conditionId)->where('client_id',$value->client_id)->get();
            foreach ($ema as $values) {
                $values->status=1;
                $values->save();
            }
        }*/
       
            $status=AppHelper::newalert();
            
        
       
       
       /*$status=AppHelper::secondarycheck();
       $status=AppHelper::updatestatus();
       $status=AppHelper::sendalert();*/
       // $status=AppHelper::sendMessage('-780723753', "WELCOME MESSAGE", false, 1, false);
    }
}
