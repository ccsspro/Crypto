<?php 
namespace App\Helpers;
use Illuminate\Http\Request;
use Ixudra\Curl\Facades\Curl;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Response;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Auth;
use Session;
use DateTime;
use \App\Model\Test;
use \App\Model\Ema;
use \App\Model\Client;
use \App\Model\Interval;
use \App\Model\Trend;
use \App\Model\Alert;
use \App\Model\Currency;
use \App\Model\Condition;
use \App\Model\Primary;
use \App\Model\Secondary;
use \App\Model\Conditions;


class AppHelper 
{
    
    //get coin price using api
     public static function getEMA($day,$coin_symbol,$periods,$timezone){
        $zone=str_replace('%2F','/',$timezone);
        //print_r($zone);die;
        $data = DB::table('ema10m15')->select('date', 'value','ema')->where('ema',$day)->where('period',$periods)->where('currency',$coin_symbol)->first();
        //print_r($data);die;
        $preema=$data->value;
       // print_r($data);die;
        date_default_timezone_set($zone);
        $date=new Carbon($data->date);
        $now=Carbon::now();
        $totalDuration = $now->diffInMinutes($date);
        if($periods=="M15"){
            $dayz=intdiv($totalDuration,15);
        }
        if($periods=="H1"){
            $dayz=intdiv($totalDuration,60);
        }
        if($periods=="H4"){
            $dayz=intdiv($totalDuration,240);
        }
        $days=$dayz+1;
        $url='https://api-fxtrade.oanda.com/v1/candles?instrument='.$coin_symbol.'&count='.$days.'&candleFormat=midpoint&granularity='.$periods.'&dailyAlignment=0&alignmentTimezone='.$timezone;
        //print_r($url);
        //echo '<br>';
        // API Call
        $response = Curl::to('https://api-fxtrade.oanda.com/v1/candles?instrument='.$coin_symbol.'&count='.$days.'&candleFormat=midpoint&granularity='.$periods.'&dailyAlignment=0&alignmentTimezone='.$timezone)->withContentType('application/json')->get();
        $data = json_decode($response, TRUE);
        //print_r($data);die;
        $total=0;
        $array = array();

        $array1= array();
        $array2= array();
        foreach($data as $key=>$value){
            array_push($array,$value);

        }
        $last=0;
        foreach($array[2] as $value){
            array_push($array2,$value['closeMid']);
        }
        $period=$day;
        $ema = array();
        $i = 0; 
        $k = number_format(2/($period+1),6,'.','');
        foreach($array[2] as $key => $data){ 
            $price=number_format($data['closeMid'],5,'.','');
            if($key == 0){
                $ema[$key] = number_format($preema,5,'.','');              
            }else{
                $ema[$key]=number_format($k*($price-$ema[$key-1])+$ema[$key-1],5,'.','');
            }            
        }
        $ema=end($ema);
        $response1 = Curl::to('https://api-fxtrade.oanda.com/v1/candles?instrument='.$coin_symbol.'&count=1&candleFormat=midpoint&granularity=D&dailyAlignment=0&alignmentTimezone='.$timezone)->withContentType('application/json')->get();
        $data1 = json_decode($response1, TRUE);
        if($day==1){
            $array1= array($value['closeMid'],$value['closeMid'],$data1['candles'][0]['highMid'],$data1['candles'][0]['lowMid'],$coin_symbol,$day,$periods);
        }else{
            $array1= array($ema,$value['closeMid'],$data1['candles'][0]['highMid'],$data1['candles'][0]['lowMid'],$coin_symbol,$day,$periods);    
        }
        
        return ($array1);
    }

    public static function sendMessage ($chatId, $message, $reply = false, $mute = false, $inst_view = false,$keyboard = false) {
            //$botToken = env("TELEGRAM_API", "743896776:AAE_I7Et1wF9rpwVN0doCLJkUH1iBOipbzc");
            $botToken = env("TELEGRAM_API", "691619627:AAFuAZ5lnLY3r0jMgxTcKw2M-6jHnmXK36Q");
            $website = "https://api.telegram.org/bot".$botToken;
            $url = $website."/sendMessage?chat_id=".$chatId."&parse_mode=HTML&text=".urlencode($message)."&disable_web_page_preview=true";
            //print_r($url);die;
            if($reply){
                $url .= "&reply_to_message_id=$reply";
            }
            if($mute){
                $url .= "&disable_notification=1";
            } 
            if($inst_view){
                $url .= "&disable_web_page_preview=1";
            }            
            if($keyboard){
                $url .= "&reply_markup=".json_encode($keyboard);
            }
            
//          file_get_contents($url);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $data = curl_exec($ch);
            //print_r($data);die;
            curl_close($ch);  
            return $data;
        }

        public static function sendMessage1 ($chatId, $message, $reply = false, $mute = false, $inst_view = false,$keyboard = false) {
            //$botToken = env("TELEGRAM_API", "743896776:AAE_I7Et1wF9rpwVN0doCLJkUH1iBOipbzc");
            $botToken = env("TELEGRAM_API", "811506439:AAGl4S7QUtjHYlh8hbQcP8Xx4f8RLHraYH0");
            $website = "https://api.telegram.org/bot".$botToken;
            $url = $website."/sendMessage?chat_id=".$chatId."&parse_mode=HTML&text=".urlencode($message)."&disable_web_page_preview=true";
            //print_r($url);die;
            if($reply){
                $url .= "&reply_to_message_id=$reply";
            }
            if($mute){
                $url .= "&disable_notification=1";
            } 
            if($inst_view){
                $url .= "&disable_web_page_preview=1";
            }            
            if($keyboard){
                $url .= "&reply_markup=".json_encode($keyboard);
            }
            
//          file_get_contents($url);
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            $data = curl_exec($ch);
            //print_r($data);die;
            curl_close($ch);  
            return $data;
        }

        public static function getEmoji($utf_code){
            $pattern = '@\\\x([0-9a-fA-F]{2})@x';
            $emoji = preg_replace_callback(
              $pattern,
              function ($captures) {
                return chr(hexdec($captures[1]));
              },
              $utf_code
            );
            return $emoji;
        }

        
        public static function primarycheck(){
            date_default_timezone_set('Europe/Berlin');
            $client_obj = Client::where('alertStatus', 1)->orderby('client_id','desc')->get();
            $trend="";
            foreach($client_obj as $client_objs){
            	$obj = Trend::where('alert',$client_objs->client_id)->first();
                //if(!$obj || (date("Y-m-d H:i:s", strtotime($objs->updated_at . "+".$client_objs->reactivateInterval."minutes"))) >= (date('Y-m-d H:i:s'))){
                if((date("Y-m-d H:i:s", strtotime($client_objs->started_at . "+".$client_objs->reactivateInterval."minutes"))) >= (date('Y-m-d H:i:s'))){
                    if((date("Y-m-d H:i:s", strtotime($client_objs->scan_start . "+".$client_objs->scanInterval."minutes"))) > (date('Y-m-d H:i:s'))){

                        $currency=explode(",",$client_objs->currency);
                        $scanInterval=$client_objs->emaPeriod;
                        $timeFrame=$client_objs->timeFrame;
                        $condition=$client_objs->crossing;
                        $timeZone=str_replace('-','%2F',$client_objs->timeZone);
                        foreach($currency as $currencies){
                            $currency=str_replace("/", "_", $currencies);
                            $alertObj=Alert::where('alertId', $client_objs->client_id)->where('currency',$currency)->first();
                            if($alertObj){    
                                $ema=AppHelper::getEMA($scanInterval,$currency,$timeFrame,$timeZone);
                            }else{
                                $alertObj= new Alert();
                                $alertObj->alertId=$client_objs->client_id;
                                $alertObj->currency=$currency;
                                $alertObj->plotting=0;
                                $alertObj->save();
                                $ema=AppHelper::getEMA($scanInterval,$currency,$timeFrame,$timeZone);
                                if($ema[1]>$ema[0]){
                                    $alertObj->prime="over";
                                    $alertObj->save();
                                }
                                else{
                                    $alertObj->prime="under";
                                    $alertObj->save();
                                }
                            }
                            $emaobj=Primary::where('alertId',$client_objs->client_id)->first();
                            if($emaobj){
                                $emaobj->price=$ema[1];
                                $emaobj->ema=$ema[0];
                                $emaobj->save();
                            }else{                      
                                $emaobj=new Primary();
                                $emaobj->alertId=$client_objs->client_id;
                                $emaobj->price=$ema[1];
                                $emaobj->ema=$ema[0];
                                $emaobj->save();
                            }

                            if($ema[1]>$ema[0]){
                                $trend="over";
                            }
                            else{
                                $trend="under";
                            }
                            if($trend!=$alertObj->prime){
                                $alertObj->prime=$trend;
                                $alertObj->save();
                                if($condition==$trend){
                                    print_r("TEST1");
                                    if($alertObj->plotting==0){
                                        $alertObj->plotting=1;
                                        $alertObj->status=1;
                                        $alertObj->save();
                                    }
                                }                  
                            }
                        }
                    }else{
                        $client_objs->scan_start=date('Y-m-d H:i:s');
                        $client_objs->status=0;
                        $client_objs->save();
                        $status=DB::table('alertLog')->where('alertId',$client_objs->client_id)->delete();
                        $condition=EMA::where('client_id',$client_objs->client_id)->get();
                        if(count($condition)>0){
                            foreach($condition as $value){
                                $value->status=0;
                                $value->save();
                                $alertObj=Conditions::where('client_id', $value->client_id)->get();
                                foreach($alertObj as $alert){
                                    $alert->status=0;
                                    $alert->save();
                                }
                                $status=DB::table('conditionLog')->where('alertId',$value->client_id)->delete();
                            }   
                        }
                    }
                }else{
                    $client_objs->started_at=date('Y-m-d H:i:s');
                    $client_objs->scan_start=date('Y-m-d H:i:s');
                    $client_objs->status=0;
                    $client_objs->save();
                    $status=DB::table('alertLog')->where('alertId',$client_objs->client_id)->delete();
                    $trend=Trend::where('alert',$client_objs->client_id)->get();
                    if(count($trend)>0){
                        $status=DB::table('trend')->where('alert',$client_objs->client_id)->delete();
                    }
                
                    $condition=EMA::where('client_id',$client_objs->client_id)->get();
                    if(count($condition)>0){
                        foreach($condition as $value){
                            $value->status=0;
                            $value->save();
                            $alertObj=Conditions::where('client_id', $value->client_id)->get();
                            foreach($alertObj as $alert){
                                $alert->status=0;
                                $alert->save();
                            }
                            $status=DB::table('conditionLog')->where('alertId',$value->client_id)->delete();
                        }   
                    }    
                }
            }
        }

              

        public static function secondarycheck(){
            $client_obj = Client::where('alertStatus', 1)->orderby('client_id','desc')->get();
            foreach($client_obj as $client_objs){
                if((date("Y-m-d H:i:s", strtotime($client_objs->started_at . "+".$client_objs->reactivateInterval."minutes"))) >= (date('Y-m-d H:i:s'))){
                    if($client_objs->status==1){
                        if((date("Y-m-d H:i:s", strtotime($client_objs->scan_start . "+".$client_objs->scanInterval."minutes"))) > (date('Y-m-d H:i:s'))){
                            print_r($client_objs->client_id);
                            $timeZone=str_replace('-','%2F',$client_objs->timeZone);
                            $ema_obj=Ema::where('client_id',$client_objs->client_id)->where('status',0)->get();
                            foreach ($ema_obj as $value){
                                $currencys=explode(",",$value->currency);
                                $condition=$value->crossing;
                                
                                foreach ($currencys as $currency) {
                                    $currency=str_replace("/", "_", $currency);
                                    $alertObj=Condition::where('alertId', $value->alert_id)->where('currency',$currency)->first();
                                    //print_r($alertObj);
                                    if($alertObj){
                                        if($alertObj->status!=1){
                                            $ema1=AppHelper::getEMA($value->emaPeriod1,$currency,$value->timeFrame,$timeZone);      
                                            $ema2=AppHelper::getEMA($value->emaPeriod2,$currency,$value->timeFrame,$timeZone);
                                        }else{
                                            break;
                                        }
                                    }else{
                                        $alertObj= new Condition();
                                        $alertObj->alertId=$value->alert_id;
                                        $alertObj->condition_id=$value->condition_id;
                                        $alertObj->currency=$currency;
                                        $alertObj->save();
                                        $ema1=AppHelper::getEMA($value->emaPeriod1,$currency,$value->timeFrame,$timeZone);      
                                        $ema2=AppHelper::getEMA($value->emaPeriod2,$currency,$value->timeFrame,$timeZone);
                                    }
                                    $emaobj=Secondary::where('alertId',$alertObj->id)->first();
                                    if($emaobj){
                                        $emaobj->ema1=$ema1[0];
                                        $emaobj->ema2=$ema2[0];
                                        $emaobj->save();
                                    }else{
                                        $emaobj=new Secondary();
                                        $emaobj->alertId=$alertObj->id;
                                        $emaobj->ema1=$ema1[0];
                                        $emaobj->ema2=$ema2[0];
                                        $emaobj->save();
                                    }

                                    if($condition=="Above"){
                                        if($ema1[0]>$ema2[0]){
                                            $alertObj->status=1;
                                            $alertObj->save();
                                        }
                                    }
                                    if($condition=="Under"){
                                        if($ema1[0]<$ema2[0]){
                                            $alertObj->status=1;
                                            $alertObj->save();
                                        }
                                    } 
                                }
                            }
                        }        
                    }
                }           
            }
        }



        public static function updatestatus(){
            $client=Alert::selectRaw('alertId, sum(status) as s,count(*) as c')->groupBy('alertId')->having('s','<>','c')->get();
            foreach ($client as $value) {
                $obj=Client::where('client_id',$value->alertId)->first();   
                $obj->status=1;
                $obj->save();
            }
            $condition_obj=Condition::selectRaw('alertId, sum(status) as s,count(*) as c')->groupBy('alertId')->having('s','<>','c')->get();
            foreach ($condition_obj as $value) {
                $obj=Conditions::where('alertId',$value->alertId)->first();   
                $obj->status=1;
                $obj->save();
            }
            $condition= Conditions::selectRaw('client_id,conditionId, sum(status) as s')->groupBy('client_id','conditionId')->having('s','>',0)->get();
            foreach($condition as $value){
                $ema=EMA::where('condition_id',$value->conditionId)->where('client_id',$value->client_id)->get();
                foreach ($ema as $values) {
                    $values->status=1;
                    $values->save();
                }
            }
        }

        public static function sendalert(){
            date_default_timezone_set('Europe/Berlin');
            $icon1=AppHelper::getEmoji('\xF0\x9F\x94\xB5');
            $icon2=AppHelper::getEmoji('\xF0\x9F\x94\xB4');
            $cur=AppHelper::getEmoji('\xF0\x9F\x92\xB0');
            $loc=AppHelper::getEmoji('\xF0\x9F\x93\x8D');
            $hod=AppHelper::getEmoji('\xF0\x9F\x93\x88');
            $lod=AppHelper::getEmoji('\xF0\x9F\x93\x89');
            $news=AppHelper::getEmoji('\xF0\x9F\x93\xB0');
            $chk=AppHelper::getEmoji('\xF0\x9F\x94\x96');

            $client_obj = Client::where('client_preference.status',1)->join('alertLog', 'client_preference.client_id','=','alertLog.alertId')->join('primary_values','alertLog.alertId','=','primary_values.alertId')->get();
            foreach ($client_obj as $value) {
                $f=0;
                $ema_obj= Ema::where('client_id',$value->client_id)->get();
                foreach ($ema_obj as $values) {
                    if($values->status==1){
                        $f++;
                    }
                }
                if($f==count($ema_obj)){
                    if($value->crossing=="over")
                    {
                        $text=$icon1.' BUY '.$icon1.chr(10);
                    }
                    if($value->crossing=="under"){
                        $text=$icon2.' SELL '.$icon2.chr(10);
                    }
                    
                    $timeZone=str_replace('-','%2F',$value->timeZone);
                   // print_r($value->timeFrame);die;
                    $ema=AppHelper::getEMA($value->emaPeriod,$value->currency,$value->timeFrame,$timeZone);
                    $text.=$cur.'Currency : '.$value->currency.chr(10);
                    $text.=$loc.'Location : EMA  '.$value->emaPeriod.chr(10);
                    $text.=$hod.'HOD :'.$ema[2].chr(10);
                    $text.=$lod.'LOD :'.$ema[3].chr(10);
                    $text.=$news.'NEWS : <a href="https://www.forexfactory.com/calendar.php">Forex Factory</a>'.chr(10); 
                    $text.=$chk.$value->alertNote.chr(10);
                    $obj = Trend::where('coin',$value->currency)->where('alert',$value->client_id)->first();
                    //print_r($obj);die;
                    if($obj){
                        if($value->crossing=!$obj->trend){
                            $status=AppHelper::sendMessage('-1001395879666', $text, false, 1, false);
                            //$status=AppHelper::sendMessage1('-386420414', $text, false, 1, false);
                            //print_r($text);
                            $obj->trend=$value->crossing;
                            $obj->save();
                        }
                    }else{
                      	$obj1=new Trend();
                       	$obj1->coin=$value->currency;
                      	$obj1->alert=$value->client_id;
                       	$obj1->trend=$value->crossing;
                       	$obj1->save();
                       	//print_r($text);
                        $status=AppHelper::sendMessage('-1001395879666', $text, false, 1, false);
                       // $status=AppHelper::sendMessage('-386420414', $text, false, 1, false);
                    }
                }
            }
        }

        public static function newalert(){
            date_default_timezone_set('Europe/Berlin');
            $status=TEST::first();
            $status->status=1;
            $status->save();
           // $status=AppHelper::sendMessage('-386420414', "WELCOME MESSAGE", false, 1, false);
            $client_obj = Client::where('alertStatus', 1)->orderby('client_id','desc')->get();
            $trend="";
            
            foreach($client_obj as $client_objs){
                $interval=Interval:: where('client_id',$client_objs->client_id)->get();
                $status=0;
                foreach ($interval as $key => $value) {
                    if(date("H:i", strtotime($value['fromInterval']))< (date('H:i')) && date("H:i", strtotime($value['toInterval']))>(date('H:i'))){
                        $status=1;
                    }
                }
                if($status==1){
                    $obj = Trend::where('alert',$client_objs->client_id)->first();
                    if(!$obj){
                    
                //if((date("Y-m-d H:i:s", strtotime($client_objs->started_at . "+".$client_objs->reactivateInterval."minutes"))) > (date('Y-m-d H:i:s'))){
                    if((date("Y-m-d H:i:s", strtotime($client_objs->scan_start . "+".$client_objs->scanInterval."minutes"))) > (date('Y-m-d H:i:s'))){
                        $currency=explode(",",$client_objs->currency);
                        $scanInterval=$client_objs->emaPeriod;
                        $timeFrame=$client_objs->timeFrame;
                        $condition=$client_objs->crossing;
                        $timeZone=str_replace('-','%2F',$client_objs->timeZone);
                        foreach($currency as $currencies){
                            $currency=str_replace("/", "_", $currencies);
                            $alertObj=Alert::where('alertId', $client_objs->client_id)->where('currency',$currency)->first();
                            if($alertObj){    
                                $ema=AppHelper::getEMA($scanInterval,$currency,$timeFrame,$timeZone);
                            }else{
                                $alertObj= new Alert();
                                $alertObj->alertId=$client_objs->client_id;
                                $alertObj->currency=$currency;
                                $alertObj->plotting=0;
                                $alertObj->save();
                                $ema=AppHelper::getEMA($scanInterval,$currency,$timeFrame,$timeZone);
                                if($ema[1]>$ema[0]){
                                    $alertObj->prime="over";
                                    $alertObj->save();
                                }
                                else{
                                    $alertObj->prime="under";
                                    $alertObj->save();
                                }
                            }
                            $emaobj=Primary::where('alertId',$client_objs->client_id)->first();
                            if($emaobj){
                                $emaobj->price=$ema[1];
                                $emaobj->ema=$ema[0];
                                $emaobj->save();
                            }else{                      
                                $emaobj=new Primary();
                                $emaobj->alertId=$client_objs->client_id;
                                $emaobj->price=$ema[1];
                                $emaobj->ema=$ema[0];
                                $emaobj->save();
                            }

                            if($ema[1]>$ema[0]){
                                $trend="over";
                            }
                            else{
                                $trend="under";
                            }
                            if($trend!=$alertObj->prime){
                                $alertObj->prime=$trend;
                                $alertObj->save();
                                if($condition==$trend){
                                    print_r("TEST1");
                                    if($alertObj->plotting==0){
                                        $alertObj->plotting=1;
                                        $alertObj->status=1;
                                        $alertObj->save();
                                    }
                                }                  
                            }
                        }
                        $client=Alert::selectRaw('alertId, sum(status) as s,count(*) as c')->groupBy('alertId')->having('s','<>','c')->get();
                        foreach ($client as $value) {
                            $obj=Client::where('client_id',$value->alertId)->first();   
                            $obj->status=1;
                            $obj->save();
                        }
                        $client= Client::where('client_id',$client_objs->client_id)->where('status',1)->first();
                        if($client){
                            $timeZone=str_replace('-','%2F',$client->timeZone);
                            $ema_obj=Ema::where('client_id',$client->client_id)->where('status',0)->get();
                            foreach ($ema_obj as $value){
                                $currencys=explode(",",$value->currency);
                                $condition=$value->crossing;
                                foreach ($currencys as $currency) {
                                    $currency=str_replace("/", "_", $currency);
                                    $alertObj=Condition::where('alertId', $value->alert_id)->where('currency',$currency)->first();
                                    if($alertObj){
                                        if($alertObj->status!=1){
                                            $ema1=AppHelper::getEMA($value->emaPeriod1,$currency,$value->timeFrame,$timeZone);      
                                            $ema2=AppHelper::getEMA($value->emaPeriod2,$currency,$value->timeFrame,$timeZone);
                                        }else{
                                            break;
                                        }
                                    }else{
                                        $alertObj= new Condition();
                                        $alertObj->alertId=$value->alert_id;
                                        $alertObj->condition_id=$value->condition_id;
                                        $alertObj->currency=$currency;
                                        $alertObj->save();
                                        $ema1=AppHelper::getEMA($value->emaPeriod1,$currency,$value->timeFrame,$timeZone);      
                                        $ema2=AppHelper::getEMA($value->emaPeriod2,$currency,$value->timeFrame,$timeZone);
                                    }
                                    $emaobj=Secondary::where('alertId',$alertObj->id)->first();
                                    if($emaobj){
                                        $emaobj->ema1=$ema1[0];
                                        $emaobj->ema2=$ema2[0];
                                        $emaobj->save();
                                    }else{
                                        $emaobj=new Secondary();
                                        $emaobj->alertId=$alertObj->id;
                                        $emaobj->ema1=$ema1[0];
                                        $emaobj->ema2=$ema2[0];
                                        $emaobj->save();
                                    }

                                    if($condition=="Above"){
                                        if($ema1[0]>$ema2[0]){
                                            $alertObj->status=1;
                                            $alertObj->save();
                                        }
                                    }
                                    if($condition=="Under"){
                                        if($ema1[0]<$ema2[0]){
                                            $alertObj->status=1;
                                            $alertObj->save();
                                        }
                                    } 
                                }
                            }
                            $condition_obj=Condition::selectRaw('alertId, sum(status) as s,count(*) as c')->groupBy('alertId')->having('s','<>','c')->get();
                            foreach ($condition_obj as $value) {
                                $obj=Conditions::where('alertId',$value->alertId)->first();   
                                $obj->status=1;
                                $obj->save();
                            }
                            $condition= Conditions::selectRaw('client_id,conditionId, sum(status) as s')->groupBy('client_id','conditionId')->having('s','>',0)->get();
                            foreach($condition as $value){
                                $ema=EMA::where('condition_id',$value->conditionId)->where('client_id',$value->client_id)->get();
                                foreach ($ema as $values) {
                                    $values->status=1;
                                    $values->save();
                                }
                            }
                        }
                        $status=AppHelper::sendalert();   
                    }else{
                        $client_objs->scan_start=date('Y-m-d H:i:s');
                        $client_objs->status=0;
                        $client_objs->save();
                        $status=DB::table('alertLog')->where('alertId',$client_objs->client_id)->delete();
                        $condition=EMA::where('client_id',$client_objs->client_id)->get();
                        if(count($condition)>0){
                            foreach($condition as $value){
                                $value->status=0;
                                $value->save();
                                $alertObj=Conditions::where('client_id', $value->client_id)->get();
                                foreach($alertObj as $alert){
                                    $alert->status=0;
                                    $alert->save();
                                }
                                $status=DB::table('conditionLog')->where('alertId',$value->alert_id)->delete();
                            }   
                        }
                    }
                }else{
                    if((date("Y-m-d H:i:s", strtotime($obj->updated_at . "+".$client_objs->reactivateInterval."minutes"))) < (date('Y-m-d H:i:s'))){
                        $client_objs->started_at=date('Y-m-d H:i:s');
                        $client_objs->scan_start=date('Y-m-d H:i:s');
                        $client_objs->status=0;
                        $client_objs->save();
                        $status=DB::table('alertLog')->where('alertId',$client_objs->client_id)->delete();
                        $trend=Trend::where('alert',$client_objs->client_id)->get();
                        if(count($trend)>0){
                            $status=DB::table('trend')->where('alert',$client_objs->client_id)->delete();
                        }
                
                        $condition=EMA::where('client_id',$client_objs->client_id)->get();
                        if(count($condition)>0){
                            foreach($condition as $value){
                                $value->status=0;
                                $value->save();
                                $alertObj=Conditions::where('client_id', $value->client_id)->get();
                                foreach($alertObj as $alert){
                                    $alert->status=0;
                                    $alert->save();
                                }
                                $status=DB::table('conditionLog')->where('alertId',$value->alert_id)->delete();
                            }   
                        }
                    }
                    /**/
                }
                }
            	
            }
            $status=TEST::first();
            $status->status=1;
            $status->save();
        }
}

?>