<?php

namespace App\Model;
use Eloquent;

class Condition extends Eloquent 
{
    protected $table = 'conditionLog';
    protected $primaryKey = 'id';
    public $timestamps = true;
}

