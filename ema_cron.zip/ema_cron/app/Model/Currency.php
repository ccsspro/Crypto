<?php

namespace App\Model;
use Eloquent;

class Currency extends Eloquent 
{
    protected $table = 'currency';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

