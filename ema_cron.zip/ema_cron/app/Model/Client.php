<?php

namespace App\Model;
use Eloquent;

class Client extends Eloquent 
{
    protected $table = 'client_preference';
    protected $primaryKey = 'client_id';
    public $timestamps = true;
}

