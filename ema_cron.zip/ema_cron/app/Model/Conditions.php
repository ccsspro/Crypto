<?php

namespace App\Model;
use Eloquent;

class Conditions extends Eloquent 
{
    protected $table = 'condition_status';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

