<?php

namespace App\Model;
use Eloquent;

class Test extends Eloquent 
{
    protected $table = 'ema_check';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

