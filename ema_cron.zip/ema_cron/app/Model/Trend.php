<?php

namespace App\Model;
use Eloquent;

class Trend extends Eloquent 
{
    protected $table = 'trend';
    protected $primaryKey = 'id';
    public $timestamps = true;
}

