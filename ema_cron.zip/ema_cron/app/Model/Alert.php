<?php

namespace App\Model;
use Eloquent;

class Alert extends Eloquent 
{
    protected $table = 'alertLog';
    protected $primaryKey = 'id';
    public $timestamps = true;
}

