<?php

namespace App\Model;
use Eloquent;

class Interval extends Eloquent 
{
    protected $table = 'interval_details';
    protected $primaryKey = 'interval_id';
    public $timestamps = false;
}

