<?php

namespace App\Model;
use Eloquent;

class Ema extends Eloquent 
{
    protected $table = 'ema_alert';
    protected $primaryKey = 'alert_id';
    public $timestamps = false;
}

