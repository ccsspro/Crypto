<?php

namespace App\Model;
use Eloquent;

class Secondary extends Eloquent 
{
    protected $table = 'secondary_values';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

