<?php

namespace App\Model;
use Eloquent;

class Primary extends Eloquent 
{
    protected $table = 'primary_values';
    protected $primaryKey = 'id';
    public $timestamps = false;
}

