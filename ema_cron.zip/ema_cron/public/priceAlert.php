<?php
namespace App\Console\Commands;

use Illuminate\Console\Command;
use Ixudra\Curl\Facades\Curl;
use App\Helpers\AppHelper;

class priceAlert extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'price:alert';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Price Alert';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {   
        $currency="EUR_USD";
        $day=10;
        $period="M15";
        $timezone="America-New_York";
        //$ema= AppHelper::getEMA(10,$currency,$period,$timezone);
        $ema1= AppHelper::getEMA(200,$currency,$period,$timezone);
        $myfile = fopen("public/ema.txt", "a") or die("Unable to open file!");
        $txt=$ema1."\n";
        fwrite($myfile, $txt);
        fclose($myfile);
    }
}
