jQuery(function($) {'use strict';

	// min height 
	var m=2;
	$(document).ready(function() {
		function setHeight() {
			var windowHeight = $(window).height();
				$('.min-height-100').css('min-height', windowHeight);
				$('.content').css('min-height', windowHeight-49);
				$('.content-wrap').css('min-height', windowHeight-190);
			}
		setHeight();
		$(window).resize(function() {
			setHeight();
		});
	});	
							
	$(document).on('click', '.remove-button-edit', function () {
		var id=$(this).attr('value');
			//console.log(el);
			//$('.edit_remove'+el).remove();
		$.ajax({
			url: "/removeedit/"+id+"/",
			type: "GET",
			dataType:'json',
			success: function(response) { 
					if(response==1){
						location.reload(true);
					}else{
						alert("Atleast one condition should be there...!!");
						location.reload(true);
					}
					
			},
		});
	});	
	
	$(document).on('click', '.edit-button', function () {
		var id=$('#getId').val();
		var data=$('#edit-form').serializeArray();
		$("#iframeloading").show();
		$.ajax({
			url: "/edit-data",
			type: "POST",
			data: {id:id,
					data: data},
			dataType:'json',
			success: function(response) { 
				$("#iframeloading").hide();
				location.reload(true);
			},
		});
	});	

	$(document).on('click', '.submit-button', function () {
		//
		
			var data=$('#entry-form').serializeArray();

		//alert(data);
		$("#iframeloading").show();
		$.ajax({
			url: "/entry-data",
			type: "POST",
			data: {data: data},
			dataType:'json',
			success: function(response) { 
				$("#iframeloading").hide();
				//location.reload(true);
			},
		});
		
		
	});
		

	// Select Two
	
	$(document).ready(function() {
		
		$('.multi-select').select2();
		
		$(".currency-multiple").select2({
			'placeholder' : "CURRENCY ",
			'multiple' : true,
			'defaultView': 'dropdown',
		});
		
		$('.form-control').attr('size', 'placeholder', $(this).val().length);
		
	});			
					
	// Time Picker
					
	 $(document).ready(function(){
		$('.timepicker').mdtimepicker(); //Initializes the time picker
	  });				

					
	// Add Dynami Feild
					
	$(function() {

		$(document).on('click', '.add-button', function () {
			var x=$(this).attr('id');
			var n = $( ".add-row" ).length;
			console.log(n);
			n++;
			
			var parentDiv = $(this).parent('p').next('div');
			console.log(parentDiv);
			var html="";
  			$.ajax({
				url: "/getcurrency",
				type: "GET",
				dataType:'json',
				success: function(response) { 
					html+='<div class="col-12 add-row add-row'+n+'"><input type="hidden" name="condition['+m+']" value='+x+'><p>EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod1['+m+']"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select> &nbsp;&nbsp; is &nbsp;&nbsp; <select class="form-control d-inline-block w-250"  name="crossing2['+m+']"><option disabled selected>Select Above or Under </option><option value="Above">Above</option><option value="Under">Under</option></select> &nbsp;&nbsp; EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod2['+m+']"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; of &nbsp;&nbsp; <select class="form-control currency-multiple d-inline-block w-250" multiple="multiple" name="currency2['+m+'][]">';
					$.each(response, function (key, val) {
        				//console.log(val.value);
        				var currency=val.currency.replace("_","/");
        				html+='<option value="'+currency+'">'+currency+'</option>';
        			});
    				html+='</select>  &nbsp;&nbsp; on &nbsp;&nbsp; <select class="form-control d-inline-block" name="timeFrame2['+m+']"><option disabled selected>Timeframe</option><option value="M15">M15</option><option value="H1">H1</option><option value="H4">H4</option></select> &nbsp;&nbsp; <a class="remove-button" data="'+n+'"></a></p></div>';					
					m++;
//			$("#add_field").append(html);
			//console.log(html);
			parentDiv.append(html);
			$(".currency-multiple").select2({
				'placeholder' : "Currency",
				'multiple' : true,
				'defaultView': 'dropdown'
			});
			
				},
			});
  			
			
			
			
			$('.timepicker').mdtimepicker();
			
		});	
		
		$(document).on('click', '.remove-button', function () {
			var el=$(this).attr('data');
			$('.add-row'+el).remove();
		});
		
	});		
					
	$(function() {

		$(document).on('click', '.add-button-new', function () {
			var x=$(this).attr('id');
			var n = $( ".add-row" ).length;
			console.log(n);
			n++;
			
			var parentDiv = $(this).parent('p').next('div');
			console.log(parentDiv);
			var html="";
  			$.ajax({
				url: "/getcurrency",
				type: "GET",
				dataType:'json',
				success: function(response) { 
					html+='<div class="col-12 add-row add-row'+n+'"><p>EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod1"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select> &nbsp;&nbsp; is &nbsp;&nbsp; <select class="form-control d-inline-block w-250"  name="crossing2"><option disabled selected>Select Above or Under </option><option value="Above">Above</option><option value="Under">Under</option></select> &nbsp;&nbsp; EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod2"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; of &nbsp;&nbsp; <select class="form-control currency-multiple d-inline-block w-250" multiple="multiple" name="currency2">';
					$.each(response, function (key, val) {
        				//console.log(val.value);
        				var currency=val.currency.replace("_","/");
        				html+='<option value="'+currency+'">'+currency+'</option>';
        			});
    				html+='</select>  &nbsp;&nbsp; on &nbsp;&nbsp; <select class="form-control d-inline-block" name="timeFrame2"><option disabled selected>Timeframe</option><option value="M15">M15</option><option value="H1">H1</option><option value="H4">H4</option></select> &nbsp;&nbsp;<input type="hidden" name="end" value="end"> <a class="remove-button" data="'+n+'"></a></p></div>';					
					m++;
//			$("#add_field").append(html);
			//console.log(html);
			parentDiv.append(html);
			$(".currency-multiple").select2({
				'placeholder' : "Currency",
				'multiple' : true,
				'defaultView': 'dropdown'
			});
			
				},
			});
  			
			
			
			
			$('.timepicker').mdtimepicker();
			
		});	
		
		$(document).on('click', '.remove-button', function () {
			var el=$(this).attr('data');
			$('.add-row'+el).remove();
		});
		
	});						
	// Add Dynami Feild
					
	$(function() {
		$(document).on('click', '.add-condition', function () {
			var n = $( ".content-row" ).length;
			console.log(n);
			n++;

  			var html='';
  			$.ajax({
				url: "/getcurrency",
				type: "GET",
				dataType:'json',
				success: function(response) { 
					html+='<div class="col-12 add-row add-row1 content-row content-row'+n+'"><div class="content-wrap-two first"><p data="'+n+'">Condition '+n+'<br/><a class="add-condition button-blue" data="'+n+'">Add Condition</a><a class="remove-condition button-red" data="'+n+'">Remove</a></p></div><div class="content-wrap-two second"><input type="hidden" name="condition['+m+']" value='+n+'><p>EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod1['+m+']"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; is &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="crossing2['+m+']"><option>Select Above or Under</option><option value="Above">Above</option><option value="Under">Under</option></select> &nbsp;&nbsp; EMA &nbsp;&nbsp;  <select class="form-control d-inline-block w-250" name="emaPeriod2['+m+']"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; of &nbsp;&nbsp; <select class="form-control currency-multiple d-inline-block w-250" multiple="multiple" name="currency2['+m+'][]">';
					$.each(response, function (key, val) {
        				var currency=val.currency.replace("_","/");
        				html+='<option value="'+currency+'">'+currency+'</option>';
    				});
    				html+='</select> &nbsp;&nbsp; on &nbsp;&nbsp; <select class="form-control d-inline-block" name="timeFrame2['+m+']"><option disabled selected>Timeframe</option><option value="M15">M15</option><option value="H1">H1</option><option value="H4">H4</option></select> &nbsp;&nbsp; <a class="add-button plus-button" id='+n+'></a></p><div id="add_field" class="row"></div></div></div>';
			
			m++;
			$('#add_condition').append(html);
						
			$(".currency-multiple").select2({
				'placeholder' : "Currency",
				'multiple' : true,
				'defaultView': 'dropdown'
			});					
				},
			});
  			
			
			$('.timepicker').mdtimepicker();
			
		});	
		
		$(document).on('click', '.remove-condition', function () {
			var el=$(this).attr('data');
			console.log(el);
			$('.content-row'+el).remove();
		});
		
	});	

	$(function() {
		$(document).on('click', '.add-condition-new', function () {
			var n = $( ".content-row" ).length;
			console.log(n);
			n++;

  			var html='';
  			$.ajax({
				url: "/getcurrency",
				type: "GET",
				dataType:'json',
				success: function(response) { 
					html+='<div class="col-12 add-row add-row1 content-row content-row'+n+'"><div class="content-wrap-two first"><p data="'+n+'">Condition '+n+'<br/><a class="add-condition-new button-blue" data="'+n+'">Add Condition</a><a class="remove-condition button-red" data="'+n+'">Remove</a></p></div><div class="content-wrap-two second"><input type="hidden" name="condition" value='+n+'><p>EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod1"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; is &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="crossing2"><option>Select Above or Under</option><option value="Above">Above</option><option value="Under">Under</option></select> &nbsp;&nbsp; EMA &nbsp;&nbsp;  <select class="form-control d-inline-block w-250" name="emaPeriod2"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; of &nbsp;&nbsp; <select class="form-control currency-multiple d-inline-block w-250" multiple="multiple" name="currency2">';
					$.each(response, function (key, val) {
        				var currency=val.currency.replace("_","/");
        				html+='<option value="'+currency+'">'+currency+'</option>';
    				});
    				html+='</select> &nbsp;&nbsp; on &nbsp;&nbsp; <select class="form-control d-inline-block" name="timeFrame2"><option disabled selected>Timeframe</option><option value="M15">M15</option><option value="H1">H1</option><option value="H4">H4</option></select> &nbsp;&nbsp;<input type="hidden" name="end" value="end"> <a class="add-button-new plus-button" id='+n+'></a></p><div id="add_field" class="row"></div></div></div>';
			
			m++;
			$('#add_condition').append(html);
						
			$(".currency-multiple").select2({
				'placeholder' : "Currency",
				'multiple' : true,
				'defaultView': 'dropdown'
			});					
				},
			});
  			
			
			$('.timepicker').mdtimepicker();
			
		});	
		
		$(document).on('click', '.remove-condition', function () {
			var el=$(this).attr('data');
			console.log(el);
			$('.content-row'+el).remove();
		});
		
	});	

	$(function() {
		$(document).on('click', '.add-condition-edit', function () {
			var n = $( ".content-row" ).length;
			console.log(n);
			n++;

  			var html='';
  			$.ajax({
				url: "/getcurrency",
				type: "GET",
				dataType:'json',
				success: function(response) { 
					html+='<div class="col-12 add-row add-row1 content-row content-row'+n+'"><div class="content-wrap-two first"><p data="'+n+'">Condition '+n+'<br/><a class="add-condition-edit button-blue" data="'+n+'">Add Condition</a><a class="remove-condition button-red" data="'+n+'">Remove</a></p></div><div class="content-wrap-two second"><input type="hidden" name="condition" value='+n+'><p>EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod1"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; is &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="crossing2"><option>Select Above or Under</option><option value="Above">Above</option><option value="Under">Under</option></select> &nbsp;&nbsp; EMA &nbsp;&nbsp;  <select class="form-control d-inline-block w-250" name="emaPeriod2"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; of &nbsp;&nbsp; <select class="form-control currency-multiple d-inline-block w-250" multiple="multiple" name="currency2">';
					$.each(response, function (key, val) {
						var currency=val.currency.replace("_","/");
        				html+='<option value="'+currency+'">'+currency+'</option>';
    				});
    				html+='</select> &nbsp;&nbsp; on &nbsp;&nbsp; <select class="form-control d-inline-block" name="timeFrame2"><option disabled selected>Timeframe</option><option value="M15">M15</option><option value="H1">H1</option><option value="H4">H4</option></select> &nbsp;&nbsp;<input type="hidden" name="end" value="end"> <a class="add-button-edit plus-button" id='+n+'></a></p><div id="add_field" class="row"></div></div></div>';
			
			m++;
			$('#add_condition').append(html);
						
			$(".currency-multiple").select2({
				'placeholder' : "Currency",
				'multiple' : true,
				'defaultView': 'dropdown'
			});					
				},
			});
  			
			
			$('.timepicker').mdtimepicker();
			
		});	
		
		$(document).on('click', '.remove-condition', function () {
			var el=$(this).attr('data');
			console.log(el);
			$('.content-row'+el).remove();
		});
		
	});	

	$(function() {

		$(document).on('click', '.add-button-edit', function () {
			var x=$(this).attr('id');
			var n = $( ".add-row" ).length;
			console.log(n);
			n++;
			
			var parentDiv = $(this).parent('p').next('div');
			console.log(parentDiv);
			var html="";
  			$.ajax({
				url: "/getcurrency",
				type: "GET",
				dataType:'json',
				success: function(response) { 
					html+='<div class="col-12 add-row add-row'+n+'"><input type="hidden" name="condition['+m+']" value='+x+'><p>EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod1"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select> &nbsp;&nbsp; is &nbsp;&nbsp; <select class="form-control d-inline-block w-250"  name="crossing2"><option disabled selected>Select Above or Under </option><option value="Above">Above</option><option value="Under">Under</option></select> &nbsp;&nbsp; EMA &nbsp;&nbsp; <select class="form-control d-inline-block w-250" name="emaPeriod2"><option value="" disabled selected>Select Period</option><option value="1">1</option><option value="5">5</option><option value="10">10</option><option value="13">13</option><option value="50">50</option><option value="200">200</option><option value="800">800</option></select>  &nbsp;&nbsp; of &nbsp;&nbsp; <select class="form-control currency-multiple d-inline-block w-250" multiple="multiple" name="currency2">';
					$.each(response, function (key, val) {
        				//console.log(val.value);
        				var currency=val.currency.replace("_","/");
        				html+='<option value="'+currency+'">'+currency+'</option>';
        			});
    				html+='</select>  &nbsp;&nbsp; on &nbsp;&nbsp; <select class="form-control d-inline-block" name="timeFrame2"><option disabled selected>Timeframe</option><option value="M15">M15</option><option value="H1">H1</option><option value="H4">H4</option></select> &nbsp;&nbsp; <input type="hidden" name="end" value="end"><a class="remove-button" data="'+n+'"></a></p></div>';					
					m++;
//			$("#add_field").append(html);
			//console.log(html);
			parentDiv.append(html);
			$(".currency-multiple").select2({
				'placeholder' : "Currency",
				'multiple' : true,
				'defaultView': 'dropdown'
			});
			
				},
			});
  			
			
			
			
			$('.timepicker').mdtimepicker();
			
		});	
		
		$(document).on('click', '.remove-button', function () {
			var el=$(this).attr('data');
			$('.add-row'+el).remove();
		});
		
	});		
			
										
	// Add Dynami Feild
					
	$(function() {
		$(document).on('click', '.add-time', function () {
			var n = $( ".add-row-time" ).length;
			console.log(n);
			n++;
			
  			var html='<div class="col-12 add-row-time add-row-number'+n+'"><p><input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="fromInterval"> &nbsp;&nbsp; to &nbsp;&nbsp; <input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="toInterval"> &nbsp;&nbsp; <a class="remove-time remove-button" data="'+n+'"></a></p></div>';
			$('#add_time').append(html);
			
			$('.timepicker').mdtimepicker();
			
		});	
		
		$(document).on('click', '.remove-time', function () {
			var el=$(this).attr('data');
			$('.add-row-number'+el).remove();
		});
		
	});						
					
	// File upload Name
					
	$("input[type='file']").on('change',function(){
		//get the file name
		var fileName = $(this).val().split('\\').pop();
//		alert(fileName);
		//replace the "Choose a file" label
		$(this).next('.custom-file-label').html(fileName);
	});				
					
					
	//back to top
	
	if ($('#back-to-top').length) {
		var scrollTrigger = 100, // px
			backToTop = function () {
				var scrollTop = $(window).scrollTop();
				if (scrollTop > scrollTrigger) {
					$('#back-to-top').addClass('show');
				} else {
					$('#back-to-top').removeClass('show');
				}
			};
		backToTop();
		$(window).on('scroll', function () {
			backToTop();
		});
		$('#back-to-top').on('click', function (e) {
			e.preventDefault();
			$('html,body').animate({
				scrollTop: 0
			}, 700);
		});
	}
					
					

});