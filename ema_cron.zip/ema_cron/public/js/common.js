$(document).ready(function(){    
//    $.getScript('http://www.geoplugin.net/javascript.gp', function() {
//        var country = geoplugin_countryName();        
//        country = (country) ? country :'Malaysia';
//        $('.city-clock').text(country);
//    });
//    	
//    setInterval( function() { 
//        // Create a newDate() object
//        var newDate = new Date();
//        // newDate() object and extract the seconds of the current time on the visitor's
//        var seconds = newDate.getSeconds();
//        // Add a leading zero to seconds value
//        $("#sec").html(( seconds < 10 ? "0" : "" ) + seconds);
//
//        // newDate() object and extract the minutes of the current time on the visitor's
//        var minutes = newDate.getMinutes();
//        // Add a leading zero to the minutes value
//        $("#min").html(( minutes < 10 ? "0" : "" ) + minutes);
//
//        //  newDate() object and extract the hours of the current time on the visitor's
//        var hours = newDate.getHours();
//        // Add a leading zero to the hours value
//        $("#hours").html(( hours < 10 ? "0" : "" ) + hours);
//        
//        if(navigator.onLine){
//            $(".internet-available").removeClass('d-none');
//        }else{
//            $(".internet-available").addClass('d-none');
//        }
//        
//    }, 1000);	
//     
//    $(document).on('click','.update-calendar',function(){      
//        $.ajax({
//            url:base_url+'updateCalendar',
//            type:"get",
//            success: function(response) {
//                if (response == "1") {
//                   window.location.href = base_url;
//                }
//            }
//        });
//    });
     
 });
 
 
 
 
  
 
 