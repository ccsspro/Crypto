<?php /* /home/vij1k5b4pqy6/public_html/ema_cron/resources/views/includes/header.blade.php */ ?>
<div class="menu-row">
	<div class="logo-wrap">
		<a href="<?php echo e(route('home')); ?>">
			<h3>Dashboard</h3>
		</a>
	</div>
	<div class="menu-wrap">
		<div class="menu-right"> 
			<div class="logout">
				<a href="<?php echo e(route('logout')); ?>">Log Out</a>
			</div>	
			<div class="alert-box">
				 <a href="<?php echo e(route('list')); ?>"><img src="<?php echo e(asset('images/alarm.svg')); ?>" class="img-fluid" alt="alert" /> Alert List</a>
			</div> 					
		</div>	
	</div>
</div>