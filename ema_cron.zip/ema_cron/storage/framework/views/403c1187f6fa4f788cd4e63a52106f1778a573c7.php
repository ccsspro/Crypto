<?php /* /home/vpiu4nwcrq8l/public_html/resources/views/auth/register.blade.php */ ?>
