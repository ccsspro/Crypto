<?php /* /home/vij1k5b4pqy6/public_html/ema_cron/resources/views/layouts/app.blade.php */ ?>
<!doctype html>
<html lang="en">
<head>
     <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body class="pushmenu-push">
    <div class="wrapper">
        <!-- Header HTML Starts Here -->
        <header>
            <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </header>
         <?php echo $__env->yieldContent('content'); ?>
         <!-- Footer  HTML Starts Here -->
        <footer>
            <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
        <!-- Footer HTML Ends Here -->
    </div>
    <!-- Wrapper Ends -->
</body>
</html>
