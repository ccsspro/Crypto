<?php /* /home/vij1k5b4pqy6/public_html/ema_cron/resources/views/includes/head.blade.php */ ?>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Dashboard</title>

<!--favicon-->
<!--<link rel="icon" href="images/favicon/favicon.png">-->

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

<!-- CSS -->
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>" type="text/css">

<!-- jQuery -->
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>