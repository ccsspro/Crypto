<?php /* /home/vpiu4nwcrq8l/public_html/resources/views/edit.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Home HTML Starts Here  -->
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="content-wrap">
					<!-- <form action="<?php echo e(asset('/')); ?>dashboard-save" method="post"> -->
					<form id="edit-form" name="edit-form">
						<?php echo e(csrf_field()); ?>

						<?php $__currentLoopData = $client_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<input type="hidden" id="getId" value="<?php echo e($value->client_id); ?>">
						<div class="row">
							<div class="col-12">
								<p>
									<select class="form-control d-inline-block" name="timeZone" required="true">
										<option value="Europe-London" <?php if($value->timeZone=="Europe-London"): ?> selected='selected' <?php endif; ?>>London, UK</option>
										<option value="Europe-Berlin" <?php if($value->timeZone=="Europe-Berlin"): ?> selected='selected' <?php endif; ?>>Berlin, Germany (GMT+1)</option>
										<option value="America-New_York" <?php if($value->timeZone=="America-New_York"): ?> selected='selected' <?php endif; ?>>New York, NY, USA (GMT-5)</option>
									</select>
								</p>
							</div>
							<div class="col-12">
								<p>Group of events</p>
								<p>
									that need to happen within &nbsp;&nbsp; 
									<input type="text" class="form-control d-inline-block w-three-digi" placeholder="Enter Time" name="scanInterval" onkeypress="return isNumberKey(event)" required="true" value="<?php echo e($value->scanInterval); ?>"> &nbsp;&nbsp; Minutes
								</p>
							</div>
						</div>
						<div class="row condition-add-row">
							<div class="col-12 content-row">
								<div class="content-wrap-one first">
									<p>
										Condition 1

									</p>
								</div>
								<div class="content-wrap-one second">
									<p>
										CLOSE PRICE &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="crossing" required="true">
											<option value="under"<?php if($value->crossing=="under"): ?> selected='selected' <?php endif; ?>>crosses under</option>
											<option value="over"<?php if($value->crossing=="over"): ?> selected='selected' <?php endif; ?>>crosses over</option>
										</select>

										&nbsp;&nbsp; EMA &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="emaPeriod" required="true">
											<option value="1"<?php if($value->emaPeriod==1): ?> selected='selected' <?php endif; ?>>1</option>
											<option value="5"<?php if($value->emaPeriod==5): ?> selected='selected' <?php endif; ?>>5</option>
											<option value="10"<?php if($value->emaPeriod==10): ?> selected='selected' <?php endif; ?>>10</option>
											<option value="13"<?php if($value->emaPeriod==13): ?> selected='selected' <?php endif; ?>>13</option>
											<option value="50"<?php if($value->emaPeriod==50): ?> selected='selected' <?php endif; ?>>50</option>
											<option value="200"<?php if($value->emaPeriod==200): ?> selected='selected' <?php endif; ?>>200</option>
											<option value="800"<?php if($value->emaPeriod==800): ?> selected='selected' <?php endif; ?>>800</option>
										</select>
										&nbsp;&nbsp; of &nbsp;&nbsp;

										<select class="form-control currency-multiple d-inline-block w-250" name="currency" required="true" value="test"> 
											<?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php ($currencies= str_replace('_','/',$currencys->currency)); ?>
												<option value="<?php echo e($currencies); ?>"<?php if($currencies==$value->currency): ?> selected='selected' <?php endif; ?>><?php echo e($currencies); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>							
										</select>

										&nbsp;&nbsp; on &nbsp;&nbsp;

										<select class="form-control d-inline-block" name="timeFrame" required="true">
											<option value="M15"<?php if($value->timeFrame=="M15"): ?> selected='selected' <?php endif; ?>>M15</option>
											<option value="H1"<?php if($value->timeFrame=="H1"): ?> selected='selected' <?php endif; ?>>H1</option>
											<option value="H4"<?php if($value->timeFrame=="H4"): ?> selected='selected' <?php endif; ?>>H4</option>
										</select>

									</p>
								</div>
							</div>
						</div>
					
						<?php ($reactive = $value->reactivateInterval); ?>
						<?php ($alertName = $value->alertName); ?>
						<?php ($alertNote = $value->alertNote); ?> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php ($i=0); ?>
						<?php ($j=1); ?>
						<?php ($m=0); ?>
						<?php ($k=0); ?>
						<?php $__currentLoopData = $ema_obj1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php ($m++); ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php $__currentLoopData = $ema_obj1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						
						<div class="row condition-add-row">	
							<div class="col-12 add-row add-row1 content-row">
								<div class="content-wrap-two first">
									<p data="<?php echo e($key+2); ?>">
										Condition <?php echo e($key+2); ?>

										<br />
										<a class="add-condition-edit button-blue" data="<?php echo e($j); ?>">Add Condition</a>
										
									</p>
								</div>
								
							
								<div class="content-wrap-two second">
									<?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keys=>$values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php ($k++); ?>
									<input type="hidden" name="conditions[<?php echo e($i); ?>]" value="<?php echo e($values->alert_id); ?>"/>
									<input type="hidden" name="condition" value="<?php echo e($values->condition_id); ?>"/>
									<p class="edit_remove<?php echo e($j); ?>" data="<?php echo e($j); ?>">
										EMA &nbsp;&nbsp;
										<select class="form-control d-inline-block w-250" name="emaPeriod1" required="true">
											<option value="1"<?php if($values->emaPeriod1==1): ?> selected='selected' <?php endif; ?>>1</option>
											<option value="5"<?php if($values->emaPeriod1==5): ?> selected='selected' <?php endif; ?>>5</option>
											<option value="10"<?php if($values->emaPeriod1==10): ?> selected='selected' <?php endif; ?>>10</option>
											<option value="13"<?php if($values->emaPeriod1==13): ?> selected='selected' <?php endif; ?>>13</option>
											<option value="50"<?php if($values->emaPeriod1==50): ?> selected='selected' <?php endif; ?>>50</option>
											<option value="200"<?php if($values->emaPeriod1==200): ?> selected='selected' <?php endif; ?>>200</option>
											<option value="800"<?php if($values->emaPeriod1==800): ?> selected='selected' <?php endif; ?>>800</option>
										</select>

										&nbsp;&nbsp; is &nbsp;&nbsp;

										<select class="form-control d-inline-block w-250" name="crossing2" required="true">
											<option value="Above"<?php if($values->crossing=="Above"): ?> selected='selected' <?php endif; ?>>Above</option>
											<option value="Under"<?php if($values->crossing=="Under"): ?> selected='selected' <?php endif; ?>>Under</option>
										</select>

										&nbsp;&nbsp; EMA &nbsp;&nbsp;

										
										<select class="form-control d-inline-block w-250" name="emaPeriod2" required="true">
											<option value="1"<?php if($values->emaPeriod2==1): ?> selected='selected' <?php endif; ?>>1</option>
											<option value="5"<?php if($values->emaPeriod2==5): ?> selected='selected' <?php endif; ?>>5</option>
											<option value="10"<?php if($values->emaPeriod2==10): ?> selected='selected' <?php endif; ?>>10</option>
											<option value="13"<?php if($values->emaPeriod2==13): ?> selected='selected' <?php endif; ?>>13</option>
											<option value="50"<?php if($values->emaPeriod2==50): ?> selected='selected' <?php endif; ?>>50</option>
											<option value="200"<?php if($values->emaPeriod2==200): ?> selected='selected' <?php endif; ?>>200</option>
											<option value="800"<?php if($values->emaPeriod2==800): ?> selected='selected' <?php endif; ?>>800</option>
										</select>

										&nbsp;&nbsp; of &nbsp;&nbsp;

										<select class="form-control currency-multiple d-inline-block w-250"  name="currency2" required="true">
												<?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currencys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php ($currencies= str_replace('_','/',$currencys->currency)); ?>
													<option value="<?php echo e($currencies); ?>"<?php if($currencies==$values->currency): ?> selected='selected' <?php endif; ?>><?php echo e($currencies); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									
										</select>

										&nbsp;&nbsp; on &nbsp;&nbsp;

										<select class="form-control d-inline-block" name="timeFrame2" required="true" data="1">
											<option value="M15"<?php if($values->crossing=="M15"): ?> selected='selected' <?php endif; ?>>M15</option>
											<option value="H1"<?php if($values->crossing=="H1"): ?> selected='selected' <?php endif; ?>>H1</option>
											<option value="H4"<?php if($values->crossing=="H4"): ?> selected='selected' <?php endif; ?>>H4</option>
										</select>
										 &nbsp;&nbsp; 
<input type="hidden" name="end" value="end">
										<?php if($k==$m): ?>
											<a class="remove-button-edit" id="<?php echo e($key+1); ?>" data="<?php echo e($j); ?>" value="<?php echo e($values->alert_id); ?>"></a> 
										<?php endif; ?>
									</p>
									<?php ($i++); ?>
									<?php ($j++); ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<div id="add_field" class="row"></div>
									

									
								</div>
							</div>					
						</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<div class="row condition-add-row" id="add_condition">
							
						</div>
						
						
										
						<div class="row select-time">
							<div class="col-12 add-row-time add-row-number1">
								<p class="mb-3">AFTER ALERT IS SENT REACTIVATE THIS ALERT AFTER &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block w-three-digi" name="reactivateInterval" placeholder="Enter Time" onkeypress="return isNumberKey(event)" required="true" value="<?php echo e($reactive); ?>"> &nbsp;&nbsp; Minutes</p>
								<p>Only send alerts from</p>
							</div>
							<?php $__currentLoopData = $interval_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
							<?php if($key==0): ?>
							<div class="col-12">
								<p>
									<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="fromInterval" required="true" value="<?php echo e($value->fromInterval); ?>">

									 &nbsp;&nbsp; to &nbsp;&nbsp; 
						
									<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="toInterval" required="true" value="<?php echo e($value->toInterval); ?>">
									 &nbsp;&nbsp; 
									
								</p>
							</div>
							<?php else: ?>					
						</div>
						<div id="add_time" class="row">
						<div class="col-12 add-row-time add-row-number'+n+'"><p>
							<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="fromInterval" value="<?php echo e($value->fromInterval); ?>"> &nbsp;&nbsp; to &nbsp;&nbsp; 
							<input type="text" class="form-control timepicker d-inline-block w-three-digi" placeholder="Interval" name="toInterval" value="<?php echo e($value->toInterval); ?>"> &nbsp;&nbsp; </p></div>
						</div>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
						<div class="row">
							<div class="col-12">
								<p>
								Alert Name &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block" name="alertName" placeholder="Enter Alert Name" required="true" value="<?php echo e($alertName); ?>">
								 &nbsp;&nbsp;  Alert Note &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block" name="alertNote" placeholder="Enter Alert Note" required="true" value="<?php echo e($alertNote); ?>">
								</p>
							</div>
						</div>

						<div class="row">
							<div class="col-xl-2 col-lg-4 col-md-6 col-sm-12 col-12">
								<button type="button" class="button-green btn-block edit-button">Update</button>
							</div>
						</div>
					</form>	
				</div>
			</div>			
		</div>
	</div>
</div>
<!-- Home HTML Ends Here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>