<?php /* /home/hmz1d5uiwl19/public_html/resources/views/login.blade.php */ ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<title>Dashboard</title>

<!--favicon-->
<!--<link rel="icon" href="images/favicon/favicon.png">-->

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
<!-- CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<link rel="stylesheet" href="css/styles.css" type="text/css">

<!-- jQuery -->
<script src="js/jquery.js"></script>

</head>

<body>

<div class="wrapper">


<!-- Login HTML Starts Here -->
<div class="login-wrap min-height-100 row equal">
	<div class="right min-height-100 col-xl-12">
		<div class="form-wrap">
			<h2 class="main-head">Login</h2>
			<!-- Form Starts Here -->
			<form method="POST" action="<?php echo e(route('login')); ?>">
				<?php echo csrf_field(); ?>
				<div class="form-group">
					<input id="email" type="email" class="w-100 form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="User Name">
					<?php if($errors->has('email')): ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($errors->first('email')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
				<div class="form-group">
					<input id="password" type="password" class="w-100 form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password">
					 <?php if($errors->has('password')): ?>
						<span class="invalid-feedback" role="alert">
							<strong><?php echo e($errors->first('password')); ?></strong>
						</span>
					<?php endif; ?>
				</div>
				<div class="form-group">
					<div class="form-group form-check float-left">
						<input type="checkbox" class="form-check-input w">
						<label class="form-check-label">Always Remember Me.</label>
					</div>
					<div class="forgot float-right">
						<a href="<?php echo e(route('password.request')); ?>" class="link">Forgot Password?</a>
					</div>
				</div>
				<div class="clearfix"></div>
				<button type="submit" class="button-green">Login</button>
			
			</form>
			<!-- Form Ends Here -->
		</div>
	</div>
</div>
<!-- Login HTML Ends Here -->	
	
	
</div>
<!-- Wrapper Ends -->


<!-- JS -->
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/mdtimepicker.min.js"></script>
<!-- Custom Javascript -->
<script src="js/custom.js"></script>

</body>
</html>
