<?php /* /home/vpiu4nwcrq8l/public_html/resources/views/details.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Home HTML Starts Here  -->
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="content-wrap">
					<form >
						<input type="hidden" name="_token" value="AuxMOXA9WKhk08m9MY1nhZjZMzRwcUcZYXLyVxxK">
						<?php $__currentLoopData = $client_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php ($id=$value->client_id); ?>
							<?php ($timezone=$value->timeZone); ?>
							<?php ($scaninterval=$value->scanInterval); ?>
							<?php ($reactive=$value->reactivateInterval); ?>
							<?php ($alertName=$value->alertName); ?>
							<?php ($alertNote=$value->alertNote); ?>
							<?php if($trend): ?>
								<?php ($date=date("Y-m-d H:i:s", strtotime($trend->updated_at . "+".$value->reactivateInterval."minutes"))); ?>
								<?php ($date1=date("M j, Y H:i:s",strtotime($date))); ?>
							<?php else: ?>
								<?php ($date=''); ?>
								<?php ($date1=''); ?>
							<?php endif; ?>	
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


						<div class="row">
							<div class="col-12">
								<p>
									<input type="text" class="form-control d-inline-block" value="<?php echo e($timezone); ?>">
								</p>
							</div>
							<input type="hidden" id="getid" value="<?php echo e($id); ?>">
							<div class="col-12">
								<p>Group of events</p>
								<p>
									that need to happen within &nbsp;&nbsp; 
									<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($scaninterval); ?>" name="scanInterval" onkeypress="return isNumberKey(event)"> &nbsp;&nbsp; Minutes
								</p>
								<p id="demo"></p>
							</div>
						</div>
					<div id="print">
						<div class="row condition-add-row">
							<div class="col-12 content-row">
								<div class="content-wrap-one first">
									<p>
										Condition 1

									</p>
								</div>
								<?php $__currentLoopData = $client_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="content-wrap-one second">
									<p>
										CLOSE PRICE &nbsp;&nbsp;
										
										<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($value->price); ?>">
										
										&nbsp;&nbsp; 
										
										<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($value->crossing); ?>">
										
										&nbsp;&nbsp; EMA &nbsp;&nbsp;

										<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($value->emaPeriod); ?>" maxlength="3" onkeypress="return isNumberKey(event)">
										
										 &nbsp;&nbsp; 
										
										<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($value->ema); ?>">
										
										&nbsp;&nbsp; of &nbsp;&nbsp;
										
										<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($value->currency); ?>">

										&nbsp;&nbsp; on &nbsp;&nbsp;
										
										<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($value->timeFrame); ?>">
										 &nbsp;&nbsp; 
										 <?php if($value->status==1): ?>
										 <img src="<?php echo e(asset('images/icon/true.png')); ?>" style="width: 2%;" />
										 <?php else: ?>
										 <img src="<?php echo e(asset('images/icon/wrong.png')); ?>" style="width: 2%;" />
										 <?php endif; ?>
									</p>
								</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
						
						<div class="row condition-add-row">	
							
							<div class="col-12 add-row add-row1 content-row">
								
								<div class="content-wrap-two first">
									<p data="2">
										Sub Conditions 
									</p>
								</div>
								<?php ($k=2); ?>
								
								<div class="content-wrap-two second">
								<?php if(count($ema_obj)==0): ?>
									Waiting for Condition 1 to be Suceess
								<?php else: ?>
									<?php $__currentLoopData = $ema_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<p>
										<?php if($values->condition_id==$k): ?>
											EMA &nbsp;&nbsp;

											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->emaPeriod1); ?>" name="emaPeriod1[1]" maxlength="3" onkeypress="return isNumberKey(event)">
											
											 &nbsp;&nbsp; 
											
											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->ema1); ?>">
											
											&nbsp;&nbsp; is &nbsp;&nbsp;
											
											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->crossing); ?>">
											
											&nbsp;&nbsp; EMA &nbsp;&nbsp;

											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->emaPeriod2); ?>" name="emaPeriod2[1]" maxlength="3" onkeypress="return isNumberKey(event)">
											
											 &nbsp;&nbsp; 
											 
											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->ema2); ?>">

											&nbsp;&nbsp; of &nbsp;&nbsp;

											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->currency); ?>">

											&nbsp;&nbsp; on &nbsp;&nbsp;

											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->timeFrame); ?>">
																	 &nbsp;&nbsp; 
											 <?php if($values->status==1): ?>
											 <img src="<?php echo e(asset('images/icon/true.png')); ?>" style="width: 2%;" />
											 <?php else: ?>
											 <img src="<?php echo e(asset('images/icon/wrong.png')); ?>" style="width: 2%;" />
											 <?php endif; ?>
										<?php else: ?>
											AND<br>
											EMA &nbsp;&nbsp;

											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->emaPeriod1); ?>" name="emaPeriod1[1]" maxlength="3" onkeypress="return isNumberKey(event)">
											
											 &nbsp;&nbsp; 
											
											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->ema1); ?>">
											
											&nbsp;&nbsp; is &nbsp;&nbsp;
											
											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->crossing); ?>">
											
											&nbsp;&nbsp; EMA &nbsp;&nbsp;

											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->emaPeriod2); ?>" name="emaPeriod2[1]" maxlength="3" onkeypress="return isNumberKey(event)">
											
											 &nbsp;&nbsp; 
											 
											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->ema2); ?>">

											&nbsp;&nbsp; of &nbsp;&nbsp;

											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->currency); ?>">

											&nbsp;&nbsp; on &nbsp;&nbsp;

											<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($values->timeFrame); ?>">
																	 &nbsp;&nbsp; 
											 <?php if($values->status==1): ?>
											 <img src="<?php echo e(asset('images/icon/true.png')); ?>" style="width: 2%;" />
											 <?php else: ?>
											 <img src="<?php echo e(asset('images/icon/wrong.png')); ?>" style="width: 2%;" />
											 <?php endif; ?>
											<?php ($k++); ?>
										<?php endif; ?>

									</p>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
								</div>
								
							</div>
												
						</div>
					</div>	
						<div class="row select-time">
							<div class="col-12 add-row-time add-row-number1">
								<p class="mb-3">AFTER ALERT IS SENT REACTIVATE THIS ALERT AFTER &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block w-three-digi" name="reactivateInterval" value="<?php echo e($reactive); ?>" onkeypress="return isNumberKey(event)"> &nbsp;&nbsp; Minutes</p>
								<p>Only send alerts from</p>
							</div>
							<?php $__currentLoopData = $interval_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-12">
								<p>
									<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($value->fromInterval); ?>" name="fromInterval[1]">

									 &nbsp;&nbsp; to &nbsp;&nbsp; 
						
									<input type="text" class="form-control d-inline-block w-three-digi" value="<?php echo e($value->toInterval); ?>" name="toInterval[1]">
									 &nbsp;&nbsp; 
								</p>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					
						</div>
						
						<div class="row">
							<div class="col-12">
								<p>
								Alert Name &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block" name="alertName" value="<?php echo e($alertName); ?>">
								 &nbsp;&nbsp;  Alert Note &nbsp;&nbsp; 
								<input type="text" class="form-control d-inline-block" name="alertNote" value="<?php echo e($alertNote); ?>">
								</p>
							</div>
						</div>

					</form>	
				</div>
			</div>			
		</div>
	</div>
</div>
<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>	
<script>

// Set the date we're counting down to
var data='<?php echo $date; ?>';
var date='<?php echo $date1; ?>'; 
var countDownDate = new Date(date).getTime();
var dt=new Date(data);
localOffset = dt.getTimezoneOffset() * 60000;
console.log(dt.getTimezoneOffset());
// Update the count down every 1 second
if(data!=''){
	var x = setInterval(function() {
var data='<?php echo $date; ?>';
var date='<?php echo $date1; ?>'; 
var countDownDate = new Date(date).getTime();
var dt=new Date(data);
localOffset = dt.getTimezoneOffset() * 60000;
console.log(dt.getTimezoneOffset());
  // Get todays date and time
	var now = new Date().getTime();

	var utc = now + localOffset;
	console.log(utc);
	var offset=2;
	var current=utc + (3600000*offset);

    
  // Find the distance between now and the count down date
  var distance = countDownDate - current;
  
   console.log(distance);  
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = "<center><b>Alert will reactivate within "+ hours + "h "
  + minutes + "m " + seconds + "s </b></center>";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "<center><b>EXPIRED</b></center>";
    
    //location.reload(true);
  }
}, 1000);
}

</script>	
<script type="text/javascript">
	setInterval(function() {
    	var id=$('#getid').val();
		$.ajax({
			url: "/detailsnew/"+id+"/",
			type: "GET",
			//data: {'id': id},
			dataType:'json',
			success: function(response) { 
				//location.reload();
				var html='';
				$.each(response.client, function(index, item) {
					html+='<div class="row condition-add-row"><div class="col-12 content-row"><div class="content-wrap-one first"><p>Condition 1</p></div><div class="content-wrap-one second"><p>CLOSE PRICE &nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" value='+item.price+'>&nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" value='+item.crossing+'>&nbsp;&nbsp; EMA &nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" value='+item.emaPeriod+' maxlength="3" onkeypress="return isNumberKey(event)">&nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" value='+item.ema+'>&nbsp;&nbsp; of &nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" value='+item.currency+'>&nbsp;&nbsp; on &nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" value='+item.timeFrame+'>&nbsp;&nbsp';										
					if(item.status==1){
						html+='<img src="<?php echo e(asset("images/icon/true.png")); ?>" style="width: 2%;" />';
					}else{
						html+='<img src="<?php echo e(asset("images/icon/wrong.png")); ?>" style="width: 2%;" />';
					}
					html+='</p></div></div></div>';
				});
				var k=2;
				html+='<div class="row condition-add-row"><div class="col-12 add-row add-row1 content-row"><div class="content-wrap-two first"><p data="2">Sub Conditions </p></div><div class="content-wrap-two second">';
				if(response.ema.length==0){
					html+='Waiting for Condition 1 to be Suceess';
				}else{
					$.each(response.ema, function(index, item) {
						html+='<p>';
						if(item.condition_id==k){
							html+='EMA &nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" value='+item.emaPeriod1+' name="emaPeriod1[1]" maxlength="3" onkeypress="return isNumberKey(event)"> &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.ema1+'> &nbsp;&nbsp; is &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.crossing+'> &nbsp;&nbsp; EMA &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.emaPeriod2+'" name="emaPeriod2[1]" maxlength="3" onkeypress="return isNumberKey(event)"> &nbsp;&nbsp;  <input type="text" class="form-control d-inline-block w-three-digi" value='+item.ema2+'> &nbsp;&nbsp; of &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.currency+'> &nbsp;&nbsp; on &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.timeFrame+'> &nbsp;&nbsp;'; 
							if(item.status==1){
								html+='<img src="<?php echo e(asset("images/icon/true.png")); ?>" style="width: 2%;" />';
							}else{
								html+='<img src="<?php echo e(asset("images/icon/wrong.png")); ?>" style="width: 2%;" />';
							}
						}else{
							html+='AND<br>EMA &nbsp;&nbsp;<input type="text" class="form-control d-inline-block w-three-digi" value='+item.emaPeriod1+' name="emaPeriod1[1]" maxlength="3" onkeypress="return isNumberKey(event)"> &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.ema1+'> &nbsp;&nbsp; is &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.crossing+'> &nbsp;&nbsp; EMA &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.emaPeriod2+'" name="emaPeriod2[1]" maxlength="3" onkeypress="return isNumberKey(event)"> &nbsp;&nbsp;  <input type="text" class="form-control d-inline-block w-three-digi" value='+item.ema2+'> &nbsp;&nbsp; of &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.currency+'> &nbsp;&nbsp; on &nbsp;&nbsp; <input type="text" class="form-control d-inline-block w-three-digi" value='+item.timeFrame+'> &nbsp;&nbsp;'; 
							if(item.status==1){
								html+='<img src="<?php echo e(asset("images/icon/true.png")); ?>" style="width: 2%;" />';
							}else{
								html+='<img src="<?php echo e(asset("images/icon/wrong.png")); ?>" style="width: 2%;" />';
							}
							k++;
						}
					html+='</p>';						
					});	
				}
				html+='</div></div></div>';					
								
				document.getElementById("print").innerHTML = html;
			},
		});
	}, 5000)
</script>						
<!-- <script src="<?php echo e(asset('js/common.js')); ?>"></script> -->
<!-- Home HTML Ends Here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>