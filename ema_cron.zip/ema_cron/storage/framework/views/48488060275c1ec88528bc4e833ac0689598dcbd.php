<?php /* /home/vpiu4nwcrq8l/public_html/resources/views/list.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="content">
	<div class="container-fluid">
		<div class="row">
			<div class="col-12">
				<div class="content-wrap">
					<div class="row">
						<div class="col-12">
							<div class="table-responsive">
								<?php echo csrf_field(); ?>
								<table id="example" class="table table-striped table-bordered" style="width:100%">
									<thead>
										<tr>
											<th>Sl No.</th>
											<th>Create Time</th>
											<th>Name</th>
											<th>Note</th>
											<th>Action</th>
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $client_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($key+1); ?></td>
											<td><?php echo e($value->created_at); ?></td>
											<td><?php echo e($value->alertName); ?></td>
											<td><?php echo e($value->alertNote); ?></td>
											<td><button class="btn btn-sm btn-secondary rounded-0 text-white emabtn mr-1"  data-toggle="modal" id="<?php echo e($value->client_id); ?>" data-target="#view_data">View</button><button class="btn btn-sm btn-info rounded-0 text-white duplicate mr-1"  id="<?php echo e($value->client_id); ?>">Duplicate</button><button class="btn btn-sm btn-secondary rounded-0 text-white emabtn mr-1" onclick="location.href='<?php echo e(route('updateDetails', $value->client_id)); ?>'">Edit</button><button class="btn btn-sm btn-warning rounded-0 text-white editbtn" onclick="location.href='<?php echo e(route('details', $value->client_id)); ?>'">Track</button></td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>

							</div>
						</div>
					</div>
				</div>
			</div>			
		</div>
	</div>
</div>

<div class="modal fade" id="view_data" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
	<div class="modal-dialog modal-dialog-centered modal-lg" role="document">
		<div class="modal-content">

			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			<span aria-hidden="true" class="text-right">&times;</span>
			</button>

			<div class="modal-body" id="model-body">
				
			</div>
		</div>
	</div>
</div>
<style>
	.close {
    float: right;
    font-size: 1.5rem;
    font-weight: 700;
    line-height: 1;
    color: #000;
    text-shadow: 0 1px 0 #fff;
    opacity: .5;
    text-align: right;
    display: inline-block;
    padding: 5px 15px !important;
}
	</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>