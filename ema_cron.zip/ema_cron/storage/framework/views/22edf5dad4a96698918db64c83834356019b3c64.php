<?php /* /home/vpiu4nwcrq8l/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php */ ?>
<?php echo e($slot); ?>

